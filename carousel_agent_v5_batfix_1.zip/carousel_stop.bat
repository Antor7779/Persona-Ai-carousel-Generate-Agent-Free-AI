@echo off
cd /d "%~dp0"
set "PYTHON_EXE=python"
%PYTHON_EXE% carousel_loop_agent.py stop
echo.
echo Stop command sent. The loop will finish its current job, then exit
echo on its own within LOOP_DELAY_SECONDS.
pause
