"""
CAROUSEL SVG EXPORT
=======================

Adobe Illustrator opens and edits SVG natively — it's Illustrator's real
interchange format (File > Open on an .svg gives you a fully editable
vector document: live, selectable text objects, movable shapes, editable
fill colors). A genuine binary .ai file can only be produced by Illustrator
itself (it's a proprietary Adobe format with no public writer), so this
module does NOT claim to produce one — it produces .svg, which Illustrator
opens and saves as .ai/.eps just as natively, with nothing lost.

Two things get exported here, both real vector content:

  1. PER-SLIDE .svg — the same background PNG each slide already has
     (ComfyUI or Pillow, whichever ran) embedded as a placed image, with
     the headline/subheadline/body/CTA text and the legibility scrim
     re-drawn as REAL, separate, directly-editable SVG <text> and <rect>
     elements on top — using the exact same wrapping/positions
     carousel_design_agent.composite_slide() used for the PNG, so the two
     match. Open it in Illustrator and every line of copy is a live text
     object you can click and retype, independent of the background art.

  2. icons/ folder — the actual icon "objects" used in that carousel
     (chart_bar, lightbulb, house, heart, gear, clock, target, check,
     spark, leaf, star, arrow_up, cup, brush, coin — whichever ones
     carousel_design_agent.pick_icon_names() chose for THIS carousel),
     each as its OWN small, fully vector, reusable .svg file in the
     carousel's own brand colors — drag any of them into another design,
     recolor or rescale freely, no rasterization.

Only ever imports from carousel_design_agent.py (a sibling file in this
same additive carousel package) — nothing shared (image_agent.py,
seo_agent.py, embedded_fonts.py) is touched or even imported here.
"""

from __future__ import annotations

import base64
import logging
from pathlib import Path
from typing import Any, Dict, List, Tuple
from xml.sax.saxutils import escape as _xml_escape

from PIL import Image, ImageDraw

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _carousel_bootstrap import PROJECT_ROOT  # noqa: E402,F401

from carousel_design_agent import (  # noqa: E402
    SLIDE_WIDTH,
    SLIDE_HEIGHT,
    get_font,
    _wrap_text,
    _hex_to_rgb,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("carousel_svg_export")

_MEASURE_IMG = Image.new("RGB", (1, 1))
_MEASURE_DRAW = ImageDraw.Draw(_MEASURE_IMG)

# Web-safe fallback stacks — Illustrator substitutes an available system
# font automatically if the exact TTF this pipeline uses isn't installed
# on the machine opening the file; text stays fully editable either way.
_HEADLINE_FONT_STACK = "Georgia, 'DejaVu Sans', Arial, sans-serif"
_BODY_FONT_STACK = "Georgia, 'DejaVu Sans', Arial, sans-serif"


def _rgb_to_hex(rgb: Tuple[int, int, int]) -> str:
    return "#{:02X}{:02X}{:02X}".format(*rgb)


def _scrim_rgb(text_color: Tuple[int, int, int], base_rgb: Tuple[int, int, int]) -> Tuple[int, int, int]:
    # mirrors carousel_design_agent._apply_text_scrim's color choice, so
    # the SVG scrim matches the PNG's scrim
    luminance = 0.299 * text_color[0] + 0.587 * text_color[1] + 0.114 * text_color[2]
    if luminance > 140:
        return tuple(max(0, int(c * 0.30)) for c in base_rgb)
    return tuple(min(255, int(c + (255 - c) * 0.88)) for c in base_rgb)


def _svg_text_block(lines: List[str], font_size: int, font_stack: str, bold: bool,
                     x: int, y_top: int, fill_hex: str, line_spacing: float = 1.15) -> Tuple[str, int]:
    """Returns (svg_markup, block_height_px) — one <text> per line, matching
    the Pillow layout's line height so the SVG and PNG line up."""
    font = get_font("headline" if bold else "body", font_size)
    ascent, descent = font.getmetrics()
    line_height = int((ascent + descent) * line_spacing)
    weight = "bold" if bold else "normal"
    parts = []
    y = y_top + ascent
    for line in lines:
        parts.append(
            f'<text x="{x}" y="{y}" font-family="{font_stack}" font-size="{font_size}" '
            f'font-weight="{weight}" fill="{fill_hex}">{_xml_escape(line)}</text>'
        )
        y += line_height
    return "\n    ".join(parts), line_height * max(len(lines), 1)


def render_slide_svg(
    background_png_path: Path,
    slide: Dict[str, Any],
    slide_role: str,
    palette: Dict[str, str],
    out_path: Path,
) -> Path:
    """
    Illustrator-editable export of ONE slide: the already-rendered
    background PNG embedded as a placed raster image, with real, separate
    SVG <text> objects for the copy on top (matching composite_slide()'s
    layout) — open in Illustrator and retype any line without touching
    the art underneath.
    """
    text_color = _hex_to_rgb(palette["text"])
    accent_color = _hex_to_rgb(palette["accent"])
    base_rgb = _hex_to_rgb(palette["bg_from"])
    text_hex = _rgb_to_hex(text_color)
    accent_hex = _rgb_to_hex(accent_color)
    scrim_hex = _rgb_to_hex(_scrim_rgb(text_color, base_rgb))

    margin = int(SLIDE_WIDTH * 0.09)
    content_width = SLIDE_WIDTH - 2 * margin
    pad = 28

    img_bytes = background_png_path.read_bytes()
    b64 = base64.b64encode(img_bytes).decode("ascii")

    layers: List[str] = [
        f'<image x="0" y="0" width="{SLIDE_WIDTH}" height="{SLIDE_HEIGHT}" '
        f'xlink:href="data:image/png;base64,{b64}" preserveAspectRatio="xMidYMid slice"/>'
    ]

    if slide_role == "hook":
        headline_font = get_font("headline", 92)
        sub_font = get_font("body", 42)
        h_lines = _wrap_text(_MEASURE_DRAW, slide.get("headline", ""), headline_font, content_width)
        s_lines = _wrap_text(_MEASURE_DRAW, slide.get("subheadline", ""), sub_font, content_width)
        y0 = int(SLIDE_HEIGHT * 0.38)
        h_markup, h_h = _svg_text_block(h_lines, 92, _HEADLINE_FONT_STACK, True, margin, y0, text_hex)
        s_markup, s_h = _svg_text_block(s_lines, 42, _BODY_FONT_STACK, False, margin, y0 + h_h + 20, accent_hex)
        total_h = h_h + 20 + s_h
        layers.append(
            f'<rect x="{margin - pad}" y="{y0 - pad}" width="{SLIDE_WIDTH - 2 * (margin - pad)}" '
            f'height="{total_h + 2 * pad}" rx="28" fill="{scrim_hex}" fill-opacity="0.50"/>'
        )
        layers.append(h_markup)
        layers.append(s_markup)
        hint_y = SLIDE_HEIGHT - 90
        layers.append(
            f'<rect x="{margin - pad}" y="{hint_y - 10}" width="{220 + pad}" height="56" '
            f'rx="20" fill="{scrim_hex}" fill-opacity="0.50"/>'
        )
        hint_markup, _ = _svg_text_block(["Swipe  →"], 32, _BODY_FONT_STACK, False, margin, hint_y, accent_hex)
        layers.append(hint_markup)

    elif slide_role == "cta":
        headline_font = get_font("headline", 76)
        body_font = get_font("body", 40)
        cta_font = get_font("headline", 46)
        h_lines = _wrap_text(_MEASURE_DRAW, slide.get("headline", ""), headline_font, content_width)
        b_lines = _wrap_text(_MEASURE_DRAW, slide.get("body", ""), body_font, content_width)
        c_lines = _wrap_text(_MEASURE_DRAW, slide.get("cta_text", ""), cta_font, content_width)
        y0 = int(SLIDE_HEIGHT * 0.30)
        h_markup, h_h = _svg_text_block(h_lines, 76, _HEADLINE_FONT_STACK, True, margin, y0, text_hex)
        b_markup, b_h = _svg_text_block(b_lines, 40, _BODY_FONT_STACK, False, margin, y0 + h_h + 16, text_hex)
        c_markup, c_h = _svg_text_block(c_lines, 46, _HEADLINE_FONT_STACK, True, margin, y0 + h_h + 16 + b_h + 50, accent_hex)
        total_h = h_h + 16 + b_h + 50 + c_h
        layers.append(
            f'<rect x="{margin - pad}" y="{y0 - pad}" width="{SLIDE_WIDTH - 2 * (margin - pad)}" '
            f'height="{total_h + 2 * pad}" rx="28" fill="{scrim_hex}" fill-opacity="0.50"/>'
        )
        layers.append(h_markup)
        layers.append(b_markup)
        layers.append(c_markup)

    else:  # content slide
        headline_font = get_font("headline", 68)
        body_font = get_font("body", 40)
        h_lines = _wrap_text(_MEASURE_DRAW, slide.get("headline", ""), headline_font, content_width)
        b_lines = _wrap_text(_MEASURE_DRAW, slide.get("body", ""), body_font, content_width)
        y0 = margin + 110
        h_markup, h_h = _svg_text_block(h_lines, 68, _HEADLINE_FONT_STACK, True, margin, y0, text_hex)
        b_markup, b_h = _svg_text_block(b_lines, 40, _BODY_FONT_STACK, False, margin, y0 + h_h + 24, text_hex)
        total_h = h_h + 24 + b_h
        layers.append(
            f'<rect x="{margin - pad}" y="{y0 - pad}" width="{SLIDE_WIDTH - 2 * (margin - pad)}" '
            f'height="{total_h + 2 * pad}" rx="28" fill="{scrim_hex}" fill-opacity="0.50"/>'
        )
        # numbered badge — solid filled chip, editable circle + text
        badge_text = f"{slide.get('slide_number', '')}".zfill(2)
        badge_text_hex = "#08090E" if (0.299 * accent_color[0] + 0.587 * accent_color[1] + 0.114 * accent_color[2]) > 140 else "#FFFFFF"
        layers.append(f'<circle cx="{margin + 35}" cy="{margin + 35}" r="35" fill="{accent_hex}"/>')
        layers.append(
            f'<text x="{margin + 35}" y="{margin + 46}" font-family="{_HEADLINE_FONT_STACK}" '
            f'font-size="34" font-weight="bold" fill="{badge_text_hex}" text-anchor="middle">{badge_text}</text>'
        )
        layers.append(h_markup)
        layers.append(b_markup)

    svg = f"""<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
     width="{SLIDE_WIDTH}" height="{SLIDE_HEIGHT}" viewBox="0 0 {SLIDE_WIDTH} {SLIDE_HEIGHT}">
  <title>{_xml_escape(slide.get('headline', slide_role))}</title>
  <g id="background">
    {layers[0]}
  </g>
  <g id="text-layer">
    {chr(10).join('    ' + l for l in layers[1:])}
  </g>
</svg>
"""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(svg, encoding="utf-8")
    return out_path


# ============================================================
# REUSABLE ICON LIBRARY — real vector icon shapes (not raster crops),
# mirroring carousel_design_agent.py's Pillow icon shapes, each as its
# own standalone, fully editable .svg. viewBox 0 0 200 200, icon centered
# at (100,100) with radius ~80.
# ============================================================

def _icon_svg_chart_bar(c1: str, c2: str) -> str:
    bars = "".join(
        f'<rect x="{20 + i * 26}" y="{180 - h}" width="20" height="{h}" fill="{c1}"/>'
        for i, h in enumerate([40, 68, 96, 128])
    )
    return bars + f'<polyline points="20,132 76,92 124,116 180,44" stroke="{c2}" stroke-width="10" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'


def _icon_svg_lightbulb(c1: str, c2: str) -> str:
    lines = "".join(
        f'<line x1="100" y1="30" x2="{100 + dx}" y2="{30 - dy}" stroke="{c2}" stroke-width="8" stroke-linecap="round"/>'
        for dx, dy in [(-56, 30), (0, 60), (56, 30)]
    )
    return (
        f'<ellipse cx="100" cy="90" rx="48" ry="52" fill="{c1}"/>'
        f'<rect x="80" y="120" width="40" height="35" fill="{c1}"/>'
        f'{lines}'
    )


def _icon_svg_house(c1: str, c2: str) -> str:
    return (
        f'<polygon points="20,100 100,20 180,100" fill="{c2}"/>'
        f'<rect x="36" y="100" width="128" height="80" fill="{c1}"/>'
        f'<rect x="84" y="132" width="32" height="48" fill="{c2}"/>'
    )


def _icon_svg_heart(c1: str, c2: str) -> str:
    return (
        f'<path d="M100,175 C40,130 15,95 15,65 C15,35 40,20 65,20 C85,20 100,35 100,55 '
        f'C100,35 115,20 135,20 C160,20 185,35 185,65 C185,95 160,130 100,175 Z" fill="{c1}"/>'
        f'<circle cx="70" cy="55" r="14" fill="{c2}"/>'
    )


def _icon_svg_gear(c1: str, c2: str) -> str:
    import math as _m
    teeth = "".join(
        f'<rect x="{100 + _m.cos(_m.radians(i * 45)) * 80 - 9}" y="{100 + _m.sin(_m.radians(i * 45)) * 80 - 9}" width="18" height="18" fill="{c1}"/>'
        for i in range(8)
    )
    return teeth + f'<circle cx="100" cy="100" r="60" fill="{c1}"/><circle cx="100" cy="100" r="24" fill="{c2}"/>'


def _icon_svg_clock(c1: str, c2: str) -> str:
    return (
        f'<circle cx="100" cy="100" r="80" fill="{c1}"/>'
        f'<line x1="100" y1="100" x2="100" y2="52" stroke="{c2}" stroke-width="9" stroke-linecap="round"/>'
        f'<line x1="100" y1="100" x2="136" y2="108" stroke="{c2}" stroke-width="9" stroke-linecap="round"/>'
    )


def _icon_svg_target(c1: str, c2: str) -> str:
    return (
        f'<circle cx="100" cy="100" r="80" fill="{c1}"/>'
        f'<circle cx="100" cy="100" r="48" fill="{c2}"/>'
        f'<circle cx="100" cy="100" r="18" fill="{c1}"/>'
    )


def _icon_svg_check(c1: str, c2: str) -> str:
    return (
        f'<circle cx="100" cy="100" r="80" fill="{c2}"/>'
        f'<polyline points="60,100 90,132 145,64" stroke="{c1}" stroke-width="16" '
        f'fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
    )


def _icon_svg_spark(c1: str, c2: str) -> str:
    dots = "".join(
        f'<circle cx="{100 + dx}" cy="{100 + dy}" r="7" fill="{c2}"/>'
        for dx, dy in [(90, -20), (-60, 70), (60, 90)]
    )
    return f'<polygon points="112,20 46,112 100,112 88,180 154,88 100,88" fill="{c1}"/>' + dots


def _icon_svg_leaf(c1: str, c2: str) -> str:
    return (
        f'<path d="M100,180 C40,180 20,120 20,80 C20,40 60,20 100,20 C140,20 180,40 180,80 '
        f'C180,120 160,180 100,180 Z" fill="{c1}"/>'
        f'<line x1="52" y1="148" x2="148" y2="52" stroke="{c2}" stroke-width="6"/>'
    )


def _icon_svg_star(c1: str, c2: str) -> str:
    import math as _m
    pts = []
    for i in range(10):
        ang = _m.radians(i * 36 - 90)
        r = 80 if i % 2 == 0 else 34
        pts.append(f"{100 + _m.cos(ang) * r:.1f},{100 + _m.sin(ang) * r:.1f}")
    return f'<polygon points="{" ".join(pts)}" fill="{c1}"/><circle cx="100" cy="100" r="12" fill="{c2}"/>'


def _icon_svg_arrow_up(c1: str, c2: str) -> str:
    return (
        f'<polygon points="68,116 132,116 100,28" fill="{c1}"/>'
        f'<rect x="85" y="112" width="30" height="68" fill="{c2}"/>'
    )


def _icon_svg_cup(c1: str, c2: str) -> str:
    steam = "".join(
        f'<line x1="{76 + i * 24}" y1="40" x2="{76 + i * 24}" y2="64" stroke="{c2}" stroke-width="6" stroke-linecap="round"/>'
        for i in range(3)
    )
    return (
        f'<rect x="44" y="76" width="112" height="88" fill="{c1}"/>'
        f'<path d="M156,88 A28,28 0 0 1 156,144" stroke="{c2}" stroke-width="9" fill="none"/>'
        f'{steam}'
    )


def _icon_svg_brush(c1: str, c2: str) -> str:
    return (
        f'<line x1="30" y1="180" x2="110" y2="70" stroke="{c2}" stroke-width="18" stroke-linecap="round"/>'
        f'<polygon points="98,86 158,26 178,46 118,106" fill="{c1}"/>'
    )


def _icon_svg_coin(c1: str, c2: str) -> str:
    return (
        f'<ellipse cx="100" cy="130" rx="70" ry="34" fill="{c2}"/>'
        f'<ellipse cx="100" cy="100" rx="70" ry="50" fill="{c1}"/>'
        f'<ellipse cx="100" cy="88" rx="34" ry="18" fill="none" stroke="{c2}" stroke-width="6"/>'
    )


_ICON_SVG_FUNCS = {
    "chart_bar": _icon_svg_chart_bar,
    "lightbulb": _icon_svg_lightbulb,
    "house": _icon_svg_house,
    "heart": _icon_svg_heart,
    "gear": _icon_svg_gear,
    "clock": _icon_svg_clock,
    "target": _icon_svg_target,
    "check": _icon_svg_check,
    "spark": _icon_svg_spark,
    "leaf": _icon_svg_leaf,
    "star": _icon_svg_star,
    "arrow_up": _icon_svg_arrow_up,
    "cup": _icon_svg_cup,
    "brush": _icon_svg_brush,
    "coin": _icon_svg_coin,
}


def _standalone_icon_svg(name: str, c1: str, c2: str) -> str:
    fn = _ICON_SVG_FUNCS.get(name, _icon_svg_star)
    body = fn(c1, c2)
    return (
        f'<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">\n'
        f'  <title>{_xml_escape(name)}</title>\n'
        f'  {body}\n'
        f'</svg>\n'
    )


def export_icon_library(icon_names: List[str], palette: Dict[str, str], out_dir: Path) -> List[Path]:
    """
    Writes one reusable, fully-vector .svg per unique icon name actually
    used in this carousel, in the carousel's own brand colors — drop any
    of them into another design, Illustrator (or any vector tool) can
    recolor/rescale them freely since they're real paths, not crops.
    """
    accent_hex = palette.get("accent", "#D8B45C")
    pop_hex = palette.get("pop", accent_hex)
    out_dir.mkdir(parents=True, exist_ok=True)
    written: List[Path] = []
    for name in sorted(set(icon_names)):
        svg = _standalone_icon_svg(name, accent_hex, pop_hex)
        p = out_dir / f"{name}.svg"
        p.write_text(svg, encoding="utf-8")
        written.append(p)
    return written
