# Running the Carousel Agent

A third, independent pipeline alongside the video and ebook ones —
same architecture (topic/niche intelligence → chunked content →
design → assemble → loop), same shared utilities reused read-only
(`seo_agent.py`, `image_agent.py`), nothing shared modified. Safe to
run alongside `ebook_loop_agent.py` and/or `video_loop_agent.py` at
the same time — separate `data/carousel/` directory, separate
history/counter/state files, no shared mutable state.

## Folder placement — works either way

These files can live directly in `ai\` (next to `seo_agent.py`) OR in
their own subfolder, e.g. `ai\carousel_agent\` — every `carousel_*.py`
starts by importing `_carousel_bootstrap.py` (also in this folder),
which searches upward for the real `ai\` directory (the one with
`seo_agent.py` in it) and adds it to `sys.path`, and works out the
actual project root from there for `data\carousel\...`. So all of
these must stay **together in the same folder as each other**
(`_carousel_bootstrap.py` included), but that folder itself can sit
anywhere under your project. Nothing else in the project needs to move.

## One-click launcher (Windows)

`run_carousel_loop.bat` — put it in this same folder, open it once,
edit the two lines at the top (your `python` path, and optionally your
ComfyUI launcher's path so it can auto-start ComfyUI if it's not
already running), then just double-click it. It installs Pillow if
missing, starts/confirms ComfyUI, and runs the loop forever —
auto-restarting itself if the Python process ever dies outright, on
top of the loop's own per-job crash handling.

Companion one-click controls (same folder, run from a second window
while the loop is running): `carousel_status.bat`, `carousel_pause.bat`,
`carousel_resume.bat`, `carousel_stop.bat`.

## What it does, end to end

1. **`carousel_design_brief.py`** — not an agent, a constants file:
   dimensions, slide-count range, max-fonts rule, the 4 proven content
   frameworks, and the premium-client verticals — all pulled from live
   research into what actually performs on Instagram and what actually
   sells in the carousel-template marketplace (Etsy/Creative Market),
   not guessed. See the sources cited at the top of the file.
2. **`carousel_niche_agent.py`** — brainstorms specific, sellable
   carousel ideas across 6 premium-client verticals, runs a real web
   search for existing template demand on each, scores every candidate
   on *design appeal* + *sellability*, and picks the best one not made
   in the last 30 days.
3. **`carousel_content_agent.py`** — writes the slide copy in chunks
   (hook → content slides, one focused LLM call each → CTA → caption
   + hashtags), then runs a **second pass** that critiques and
   tightens every slide. That second pass is the real mechanism behind
   "take longer, make it better" — an actual extra reasoning step, not
   a fake delay.
4. **`carousel_design_agent.py`** — background art, **content-aware**:
   it reads each slide's own headline/body (plus real market-search
   result titles from step 2) and matches keywords to a small set of
   original vector icon "objects" (chart, lightbulb, house, heart,
   gear, clock, target, check, spark, leaf, star, arrow, cup, brush,
   coin), so different slides in the same carousel get different,
   relevant imagery instead of one recycled abstract graphic. If
   ComfyUI is running, those same objects and a "colorful, premium,
   playful, good-vibes" style brief go straight into the prompt. If
   not, the Pillow fallback draws a vivid three-stop brand-color
   gradient (base → accent → highlight) plus several of those vector
   icons at varied size/position — never a flat single color with one
   circle. Kept **separate** from the text, which is composited on
   top from the manuscript JSON's strings. Also renders a fully
   editable `editable.html` (real CSS text, not a picture).
5. **`carousel_svg_export.py`** — turns each rendered slide into a
   real, Illustrator-openable `.svg` (background image placed, copy on
   top as live SVG `<text>` objects — see below), plus exports that
   carousel's actual icon "objects" as their own small, fully-vector,
   reusable `.svg` files.
6. **`carousel_assembler.py`** — lays everything out into one
   numbered, self-contained folder per carousel (see below).
7. **`carousel_master_agent.py`** — orchestrates steps 2-6 for one
   carousel.
8. **`carousel_loop_agent.py`** — runs it forever, pause/resume/stop
   just like the other two loops.

## Why "editable" is real here, not just a claim

Every slide's text lives as plain strings in `slides_content.json` —
that file is the single source of truth. Two things are generated
from it, and both can be regenerated any time you edit that JSON:

- The PNGs (`slide_01_...png` etc.) — pixel-perfect, ready to upload,
  but a flattened image.
- `editable.html` — the actual copy as real, `contenteditable` HTML
  text. Open it in any browser and every headline/body/CTA line is
  directly editable, no dependency on Pillow, fonts, or ComfyUI ever
  being available again.

Edit the JSON (or the HTML, if you're just eyeballing wording) and
re-run `carousel_design_agent.py`'s compositing step to get updated
PNGs that match.

## Opening slides in Adobe Illustrator

Each slide also gets a `.svg` file (`slide_01_hook.svg`, etc.) —
Illustrator opens `.svg` natively via File > Open, and it's a real
editable document there: the background is a placed image, and the
headline/subheadline/body/CTA copy sits on top as **separate, live
text objects** you can click and retype, restyle, or move, independent
of the art underneath.

One honest caveat: there's no public writer for Adobe's actual binary
`.ai` format (it's proprietary, Illustrator-only), so this pipeline
can't produce a `.ai` file directly. `.svg` is the real equivalent —
Illustrator opens, edits, and re-saves it as `.ai`/`.eps` itself with
nothing lost, so `File > Save As > Illustrator (.ai)` right after
opening gets you a native `.ai` file in one step if you want one on
disk.

`icons/` (inside each carousel's folder) holds that carousel's actual
icon "objects" — whichever ones were picked for its slides — each as
its own small, fully vector `.svg` (not a crop of the slide), in that
carousel's brand colors. Drag any of them into another design, and
recolor or rescale freely since they're real paths.

## 1. Run it

**One carousel, auto-picked niche:**
```bash
python ai/carousel_master_agent.py
```

**One carousel on a topic you choose:**
```bash
python ai/carousel_master_agent.py \
  --title "The 3 Pricing Mistakes Killing Your Discovery Calls" \
  --vertical business_coaches_consultants \
  --framework problem_agitation_solution
```

**Skip the quality-refine pass** (faster, lower quality — for quick tests only):
```bash
python ai/carousel_master_agent.py --no-refine
```

**Run forever:**
```bash
python ai/carousel_loop_agent.py run
```
From another terminal:
```bash
python ai/carousel_loop_agent.py status
python ai/carousel_loop_agent.py pause
python ai/carousel_loop_agent.py resume
python ai/carousel_loop_agent.py stop
```

## Where things land

Every carousel gets its own numbered folder —
`data/carousel/output/<NNN>_<slug>/`:

```
002_the_5_minute_listing_photo_checklist/
├── slides_content.json       <- editable source of truth
├── editable.html             <- browser-editable version
├── slide_01_hook.png         <- upload in this filename order
├── slide_01_hook.svg         <- same slide, opens in Adobe Illustrator
├── slide_02_content.png
├── slide_02_content.svg
├── ...
├── slide_09_cta.png
├── slide_09_cta.svg
├── icons/                      <- this carousel's icon objects, as
│                                   reusable, fully-vector .svg files
├── backgrounds/               <- raw pre-text art, per slide
├── thumbnail.jpg              <- slide 1, small, for quick preview
├── caption_and_hashtags.txt   <- ready to paste into Instagram
└── metadata.txt               <- vertical, framework, suggested price,
                                   posting notes, alt-text pointer
```

Niche history (30-day no-repeat): `data/carousel/niche_history.json`
Loop state: `data/carousel/loop_state.json`

## Honest caveats

- **Content quality depends entirely on Ollama being reachable and
  good**, same as the ebook pipeline. Without it, every slide falls
  back to a plain template string — still a complete, correctly
  structured folder, just not sellable copy. Read the generated
  `slides_content.json` before actually posting/selling anything.
- **Design research grounds the *patterns* (dimensions, slide count,
  frameworks, typography discipline), not any specific paid product.**
  Nothing in this pipeline reproduces a particular Etsy/Creative
  Market seller's actual artwork or copy — every background and every
  line of text is generated fresh from the brief.
- Backgrounds without ComfyUI running are a real, colorful, on-brand
  gradient-plus-icon design (not a placeholder), but won't match
  ComfyUI's generative variety or photorealistic rendering — start
  ComfyUI first for the full visual range.
- The reference-image request to use a real person's likeness (from a
  linked video) as an AI generation reference was intentionally NOT
  implemented — that's using someone's identity without consent,
  which risks impersonation/right-of-publicity problems for content
  sold to clients. If you want a consistent recurring character
  across carousels, `character_profile.py`'s pattern (an original,
  AI-generated mascot, optionally locked with ComfyUI IPAdapter
  FaceID for consistency) is the safe equivalent — already used by
  the video pipeline.
