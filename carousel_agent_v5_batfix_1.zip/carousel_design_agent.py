"""
CAROUSEL DESIGN AGENT
========================

Turns a carousel_content_agent.py manuscript into actual pixels — and,
critically, into an EDITABLE source, not just a flattened picture.

Two independent visual layers, kept separate on purpose:
  1. BACKGROUND ART — pure background, no text baked in (via ComfyUI/
     image_agent.py if running, else a real Pillow gradient+shape design,
     never a flat placeholder box). Saved separately in backgrounds/ so
     it can be reused or redesigned without touching the copy.
  2. TEXT — composited on top with Pillow using real fonts at fixed,
     role-aware positions. Because this is a separate, deterministic
     step driven entirely by the manuscript JSON's strings, changing the
     JSON and re-running this module is all "editing" a slide requires.

A third, independent EDITABLE.HTML export (real CSS text nodes, not an
image) is generated alongside the PNGs — open it in any browser or text
editor and every word is a normal, selectable, editable HTML element.
That's the most robust "editable" guarantee: it never depends on Pillow,
fonts, or ComfyUI being available later to still be editable.

Deliberately does NOT use image_agent.build_scene_prompt() — that helper
hardcodes "A single coherent real-world photographic scene" and "visual
storytelling rather than graphic design" into every prompt (right for the
video pipeline's photographic style, wrong for a flat premium carousel
background). This module builds its own prompt and calls
image_agent.generate_image() directly instead.

Nothing in this file is imported by, or imports changes into, any
existing video/ebook module — image_agent.py, seo_agent.py, and
config_loader.py are only ever read from, never modified.
"""

from __future__ import annotations

import logging
import math
import random
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image, ImageDraw, ImageFont, ImageFilter

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _carousel_bootstrap import PROJECT_ROOT  # noqa: E402 — resolves ai/ + project root regardless of subfolder placement

from carousel_design_brief import (  # noqa: E402
    SLIDE_WIDTH,
    SLIDE_HEIGHT,
    ICON_KEYWORD_MAP,
    ICON_PROMPT_PHRASES,
    DEFAULT_ICONS_BY_VERTICAL,
    IMAGE_STYLE_MODIFIERS,
    CAROUSEL_NEGATIVE_PROMPT,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("carousel_design_agent")

BASE_DIR = PROJECT_ROOT
BG_SUBDIR = "backgrounds"

try:
    import image_agent as _ia
    HAS_IMAGE_AGENT = True
except Exception as e:
    HAS_IMAGE_AGENT = False
    logger.warning(f"image_agent.py unavailable — ComfyUI backgrounds disabled: {e}")


# ============================================================
# FONTS — separate from embedded_fonts.py (that one is reportlab/PDF-
# specific and shared with the ebook pipeline; this is Pillow-specific
# and only used here, so the two never conflict).
# ============================================================

_FONT_CANDIDATES = [
    # (display/headline bold, body regular)
    (r"C:\Windows\Fonts\georgiab.ttf", r"C:\Windows\Fonts\georgia.ttf"),
    (r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\arial.ttf"),
    ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
     "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
     "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"),
    ("/Library/Fonts/Arial Bold.ttf", "/Library/Fonts/Arial.ttf"),
    ("/System/Library/Fonts/Supplemental/Arial Bold.ttf",
     "/System/Library/Fonts/Supplemental/Arial.ttf"),
]

_font_cache: Dict[Tuple[str, int], ImageFont.FreeTypeFont] = {}
_font_paths: Optional[Tuple[str, str]] = None


def _resolve_font_paths() -> Tuple[Optional[str], Optional[str]]:
    global _font_paths
    if _font_paths is not None:
        return _font_paths
    for bold_path, regular_path in _FONT_CANDIDATES:
        if Path(bold_path).exists() and Path(regular_path).exists():
            _font_paths = (bold_path, regular_path)
            return _font_paths
    logger.warning("No TrueType font pair found — falling back to PIL's default bitmap font.")
    _font_paths = (None, None)
    return _font_paths


def get_font(role: str, size: int) -> ImageFont.ImageFont:
    """role: 'headline' (bold) or 'body' (regular) — MAX_FONTS=2 rule
    lives here: exactly these two font FILES are ever used, only size
    varies by slide role."""
    key = (role, size)
    if key in _font_cache:
        return _font_cache[key]
    bold_path, regular_path = _resolve_font_paths()
    path = bold_path if role == "headline" else regular_path
    try:
        font = ImageFont.truetype(path, size) if path else ImageFont.load_default(size=size)
    except Exception:
        font = ImageFont.load_default()
    _font_cache[key] = font
    return font


# ============================================================
# COLOR PALETTES — one per vertical, so "a defined brand color scheme
# across all slides" (the researched best-practice) is structural, not
# left to chance each run.
# ============================================================

PALETTES: Dict[str, Dict[str, str]] = {
    "business_coaches_consultants": {"bg_from": "#1B1F3B", "bg_to": "#3A2E6E", "text": "#FFFFFF", "accent": "#E8C57A", "pop": "#FF6B6B"},
    "real_estate_agents":           {"bg_from": "#0F3D3E", "bg_to": "#155E63", "text": "#FFFFFF", "accent": "#F2E9DC", "pop": "#FFB84D"},
    "wellness_medspa":               {"bg_from": "#EDE6DA", "bg_to": "#D9CBB5", "text": "#3B352A", "accent": "#8A7355", "pop": "#E07A5F"},
    "financial_and_legal_advisors":  {"bg_from": "#101820", "bg_to": "#1D2D3E", "text": "#FFFFFF", "accent": "#C9A227", "pop": "#4FC3F7"},
    "boutique_hospitality":          {"bg_from": "#3B1F1A", "bg_to": "#6B3A2E", "text": "#FBEFE6", "accent": "#E0A96D", "pop": "#F4A259"},
    "interior_design_and_home":      {"bg_from": "#F5F1EA", "bg_to": "#E3DACB", "text": "#2B2620", "accent": "#A98467", "pop": "#8FA998"},
}
_DEFAULT_PALETTE = {"bg_from": "#20232B", "bg_to": "#3A3F4B", "text": "#FFFFFF", "accent": "#D8B45C", "pop": "#5CC8D8"}


def get_palette(vertical: str) -> Dict[str, str]:
    return PALETTES.get(vertical, _DEFAULT_PALETTE)


def _hex_to_rgb(h: str) -> Tuple[int, int, int]:
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _lerp_rgb(a: Tuple[int, int, int], b: Tuple[int, int, int], t: float) -> Tuple[int, int, int]:
    return (
        int(a[0] + (b[0] - a[0]) * t),
        int(a[1] + (b[1] - a[1]) * t),
        int(a[2] + (b[2] - a[2]) * t),
    )


# ============================================================
# CONTENT-AWARE ICON SELECTION — picks which real objects/icons show up
# in a slide's art based on words that actually appear in THAT slide's own
# headline/body (or, failing that, real market-search titles / the
# vertical's default set) — this is what makes "generate images on
# contents" real instead of a generic per-vertical backdrop.
# ============================================================

def _slide_text_blob(topic: str, slide: Optional[Dict[str, Any]], market_keywords: Optional[List[str]]) -> str:
    parts = [topic or ""]
    if slide:
        for key in ("headline", "subheadline", "body", "cta_text"):
            v = slide.get(key)
            if v:
                parts.append(str(v))
    if market_keywords:
        parts.extend(str(k) for k in market_keywords)
    return " . ".join(parts).lower()


def pick_icon_names(vertical: str, topic: str = "", slide: Optional[Dict[str, Any]] = None,
                     market_keywords: Optional[List[str]] = None, max_icons: int = 3) -> List[str]:
    blob = _slide_text_blob(topic, slide, market_keywords)
    matched: List[str] = []
    for kw, icon in ICON_KEYWORD_MAP.items():
        if kw in blob and icon not in matched:
            matched.append(icon)
        if len(matched) >= max_icons:
            break
    if len(matched) < max_icons:
        defaults = DEFAULT_ICONS_BY_VERTICAL.get(vertical, ["star", "spark", "chart_bar"])
        for icon in defaults:
            if icon not in matched:
                matched.append(icon)
            if len(matched) >= max_icons:
                break
    return matched[:max_icons] or ["star"]


def _icon_prompt_phrase(icon_names: List[str]) -> str:
    phrases = [ICON_PROMPT_PHRASES.get(name, "a bold decorative shape") for name in icon_names]
    return ", ".join(phrases)


# ============================================================
# ICON DRAWING PRIMITIVES — small, original vector shapes built purely
# from Pillow polygons/ellipses/lines (no external art, no traced icon
# packs). Used as real "objects" in the Pillow fallback background so even
# a no-ComfyUI run isn't just a flat gradient with a circle.
# ============================================================

def _draw_icon_chart_bar(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    bar_w = max(6, r // 4)
    heights = [r * 0.5, r * 0.85, r * 1.2, r * 1.6]
    for i, h in enumerate(heights):
        x0 = cx - r + i * (bar_w + 6)
        d.rectangle([x0, cy + r - h, x0 + bar_w, cy + r], fill=color)
    d.line([cx - r, cy + r * 0.4, cx - r * 0.3, cy - r * 0.1, cx + r * 0.3, cy + r * 0.2, cx + r, cy - r * 0.7],
           fill=color2, width=max(3, r // 12))


def _draw_icon_lightbulb(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.ellipse([cx - r * 0.6, cy - r, cx + r * 0.6, cy + r * 0.3], fill=color)
    d.rectangle([cx - r * 0.25, cy + r * 0.15, cx + r * 0.25, cy + r * 0.5], fill=color)
    for ang in (-40, 0, 40):
        rad = math.radians(ang - 90)
        x2 = cx + math.cos(rad) * r * 1.5
        y2 = cy - r * 1.1 + math.sin(rad) * r * 1.5
        d.line([cx, cy - r, x2, y2], fill=color2, width=max(3, r // 14))


def _draw_icon_house(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.polygon([(cx - r, cy), (cx, cy - r), (cx + r, cy)], fill=color2)
    d.rectangle([cx - r * 0.8, cy, cx + r * 0.8, cy + r], fill=color)
    d.rectangle([cx - r * 0.2, cy + r * 0.35, cx + r * 0.2, cy + r], fill=color2)


def _draw_icon_heart(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.pieslice([cx - r, cy - r, cx, cy], 180, 360, fill=color)
    d.pieslice([cx, cy - r, cx + r, cy], 180, 360, fill=color)
    d.polygon([(cx - r, cy - r * 0.1), (cx + r, cy - r * 0.1), (cx, cy + r)], fill=color)
    d.ellipse([cx - r * 0.25, cy - r * 0.55, cx + r * 0.05, cy - r * 0.25], fill=color2)


def _draw_icon_gear(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    teeth = 8
    for i in range(teeth):
        ang = math.radians(i * (360 / teeth))
        x = cx + math.cos(ang) * r
        y = cy + math.sin(ang) * r
        d.rectangle([x - r * 0.12, y - r * 0.12, x + r * 0.12, y + r * 0.12], fill=color)
    d.ellipse([cx - r * 0.75, cy - r * 0.75, cx + r * 0.75, cy + r * 0.75], fill=color)
    d.ellipse([cx - r * 0.3, cy - r * 0.3, cx + r * 0.3, cy + r * 0.3], fill=color2)


def _draw_icon_clock(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color)
    d.line([cx, cy, cx, cy - r * 0.6], fill=color2, width=max(3, r // 10))
    d.line([cx, cy, cx + r * 0.45, cy + r * 0.1], fill=color2, width=max(3, r // 10))


def _draw_icon_target(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color)
    d.ellipse([cx - r * 0.6, cy - r * 0.6, cx + r * 0.6, cy + r * 0.6], fill=color2)
    d.ellipse([cx - r * 0.22, cy - r * 0.22, cx + r * 0.22, cy + r * 0.22], fill=color)


def _draw_icon_check(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color2)
    d.line([cx - r * 0.5, cy, cx - r * 0.1, cy + r * 0.4, cx + r * 0.55, cy - r * 0.45],
           fill=color, width=max(4, r // 8), joint="curve")


def _draw_icon_spark(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.polygon([
        (cx + r * 0.15, cy - r), (cx - r * 0.45, cy + r * 0.15), (cx, cy + r * 0.15),
        (cx - r * 0.15, cy + r), (cx + r * 0.45, cy - r * 0.15), (cx, cy - r * 0.15),
    ], fill=color)
    for i in range(3):
        ang = math.radians(i * 120 + 30)
        x = cx + math.cos(ang) * r * 1.3
        y = cy + math.sin(ang) * r * 1.3
        d.ellipse([x - r * 0.08, y - r * 0.08, x + r * 0.08, y + r * 0.08], fill=color2)


def _draw_icon_leaf(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.pieslice([cx - r, cy - r, cx + r, cy + r], -50, 130, fill=color)
    d.line([cx - r * 0.6, cy + r * 0.5, cx + r * 0.6, cy - r * 0.5], fill=color2, width=max(2, r // 16))


def _draw_icon_star(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    pts = []
    for i in range(10):
        ang = math.radians(i * 36 - 90)
        rr = r if i % 2 == 0 else r * 0.42
        pts.append((cx + math.cos(ang) * rr, cy + math.sin(ang) * rr))
    d.polygon(pts, fill=color)
    d.ellipse([cx - r * 0.15, cy - r * 0.15, cx + r * 0.15, cy + r * 0.15], fill=color2)


def _draw_icon_arrow_up(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.polygon([(cx - r * 0.4, cy + r * 0.2), (cx + r * 0.4, cy + r * 0.2), (cx, cy - r * 0.9)], fill=color)
    d.rectangle([cx - r * 0.15, cy + r * 0.15, cx + r * 0.15, cy + r], fill=color2)


def _draw_icon_cup(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.rectangle([cx - r * 0.7, cy - r * 0.3, cx + r * 0.7, cy + r * 0.7], fill=color)
    d.arc([cx + r * 0.5, cy - r * 0.15, cx + r * 1.1, cy + r * 0.45], -90, 90, fill=color2, width=max(3, r // 10))
    for i in range(3):
        x = cx - r * 0.3 + i * r * 0.3
        d.line([x, cy - r * 0.5, x, cy - r * 0.3], fill=color2, width=max(2, r // 16))


def _draw_icon_brush(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.line([cx - r, cy + r, cx + r * 0.3, cy - r * 0.3], fill=color2, width=max(6, r // 5))
    d.polygon([(cx + r * 0.1, cy - r * 0.5), (cx + r * 0.9, cy - r * 1.1),
               (cx + r, cy - r * 0.9), (cx + r * 0.3, cy - r * 0.3)], fill=color)


def _draw_icon_coin(d: ImageDraw.ImageDraw, cx: int, cy: int, r: int, color, color2) -> None:
    d.ellipse([cx - r, cy - r * 0.5, cx + r, cy + r * 0.5], fill=color2)
    d.ellipse([cx - r, cy - r, cx + r, cy], fill=color)
    d.ellipse([cx - r * 0.5, cy - r * 0.7, cx + r * 0.5, cy - r * 0.3], outline=color2, width=max(2, r // 14))


_ICON_DRAW_FUNCS = {
    "chart_bar": _draw_icon_chart_bar,
    "lightbulb": _draw_icon_lightbulb,
    "house": _draw_icon_house,
    "heart": _draw_icon_heart,
    "gear": _draw_icon_gear,
    "clock": _draw_icon_clock,
    "target": _draw_icon_target,
    "check": _draw_icon_check,
    "spark": _draw_icon_spark,
    "leaf": _draw_icon_leaf,
    "star": _draw_icon_star,
    "arrow_up": _draw_icon_arrow_up,
    "cup": _draw_icon_cup,
    "brush": _draw_icon_brush,
    "coin": _draw_icon_coin,
}


# ============================================================
# BACKGROUND ART
# ============================================================

def _dot_grid_overlay(size: Tuple[int, int], color: Tuple[int, int, int], spacing: int = 46, r: int = 2, opacity: int = 40) -> Image.Image:
    """A fine, low-opacity dot grid — a real premium-template texture cue
    (editorial/print-inspired), not just a flat color field."""
    overlay = Image.new("RGBA", size, (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    for y in range(spacing // 2, size[1], spacing):
        for x in range(spacing // 2, size[0], spacing):
            d.ellipse([x - r, y - r, x + r, y + r], fill=(*color, opacity))
    return overlay


def _pillow_gradient_background(
    palette: Dict[str, str], slide_role: str, icon_names: List[str], seed_key: str = ""
) -> Image.Image:
    """
    Real premium-looking fallback when ComfyUI isn't running. Layered, like
    an actual designer template rather than a flat color box:
      1. a bold, saturated THREE-stop diagonal gradient (brand -> accent ->
         pop, straight from the vertical's own palette — no muddying blend)
      2. a large rotated color-block panel (a real graphic-design device,
         not a circle) in a contrasting palette color
      3. a fine dot-grid texture for print/editorial polish
      4. 5+ original, content-matched vector icon "objects", each with a
         soft drop shadow for depth, at varied sizes/opacity
      5. thin corner frame accents, a premium-template finishing touch
    """
    from_rgb = _hex_to_rgb(palette["bg_from"])
    mid_rgb = _hex_to_rgb(palette["accent"])
    to_rgb = _hex_to_rgb(palette.get("pop", palette["bg_to"]))

    # ---- 1. bold three-stop gradient, kept saturated (legibility is
    # handled by composite_slide's text scrim, not by muting the palette) ----
    img = Image.new("RGB", (SLIDE_WIDTH, SLIDE_HEIGHT), from_rgb)
    px = img.load()
    diag = SLIDE_WIDTH + SLIDE_HEIGHT
    for y in range(SLIDE_HEIGHT):
        for x in range(0, SLIDE_WIDTH, 3):
            t = (x + y) / diag
            rgb = _lerp_rgb(from_rgb, mid_rgb, t * 2) if t < 0.5 else _lerp_rgb(mid_rgb, to_rgb, (t - 0.5) * 2)
            for dx in range(3):
                if x + dx < SLIDE_WIDTH:
                    px[x + dx, y] = rgb
    img = img.filter(ImageFilter.SMOOTH)

    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    accent = _hex_to_rgb(palette["accent"])
    pop = _hex_to_rgb(palette.get("pop", palette["accent"]))
    rnd = random.Random(f"{seed_key}:{slide_role}")

    # ---- 2. rotated color-block panel — a real graphic-design shape,
    # gives the frame a structured, "someone designed this" feel ----
    panel_size = int(SLIDE_WIDTH * 1.35)
    panel = Image.new("RGBA", (panel_size, panel_size), (0, 0, 0, 0))
    pdraw = ImageDraw.Draw(panel)
    panel_color = pop if slide_role != "cta" else accent
    pdraw.rectangle([panel_size * 0.62, 0, panel_size, panel_size], fill=(*panel_color, 46))
    panel = panel.rotate(rnd.choice([12, -12, 18, -18]), resample=Image.BICUBIC, expand=False)
    anchor = {"hook": (-int(panel_size * 0.28), -int(panel_size * 0.18)),
              "content": (int(SLIDE_WIDTH - panel_size * 0.72), -int(panel_size * 0.22)),
              "cta": (-int(panel_size * 0.30), int(SLIDE_HEIGHT - panel_size * 0.7))}
    ax, ay = anchor.get(slide_role, (int(SLIDE_WIDTH * 0.15), -int(panel_size * 0.2)))
    overlay.alpha_composite(panel, (ax, ay))

    # ---- 3. fine dot-grid texture across the whole frame ----
    dot_color = _hex_to_rgb(palette["text"])
    overlay = Image.alpha_composite(overlay, _dot_grid_overlay(img.size, dot_color, opacity=26))

    # ---- 4. content-matched vector icons with soft drop shadows ----
    odraw = ImageDraw.Draw(overlay)
    role_offsets = {
        "hook": [(0.16, 0.12), (0.85, 0.20), (0.80, 0.82), (0.15, 0.86), (0.52, 0.06)],
        "content": [(0.88, 0.14), (0.10, 0.80), (0.50, 0.92), (0.90, 0.60), (0.08, 0.15)],
        "cta": [(0.50, 0.08), (0.12, 0.82), (0.88, 0.82), (0.85, 0.15), (0.15, 0.15)],
    }
    positions = role_offsets.get(slide_role, [(0.8, 0.15), (0.2, 0.85), (0.5, 0.5), (0.15, 0.15), (0.85, 0.85)])
    names = (icon_names or ["star"])
    while len(names) < len(positions):
        names = names + (icon_names or ["star"])
    for i, (ox, oy) in enumerate(positions):
        name = names[i % len(names)]
        fn = _ICON_DRAW_FUNCS.get(name, _draw_icon_star)
        cx, cy = int(SLIDE_WIDTH * ox), int(SLIDE_HEIGHT * oy)
        r = int(SLIDE_WIDTH * rnd.uniform(0.075, 0.155))
        shadow_off = max(4, r // 10)
        try:
            fn(odraw, cx + shadow_off, cy + shadow_off, r, (0, 0, 0, 55), (0, 0, 0, 55))
        except Exception:
            odraw.ellipse([cx + shadow_off - r, cy + shadow_off - r, cx + shadow_off + r, cy + shadow_off + r], fill=(0, 0, 0, 55))
        col1 = (*accent, 205) if i % 2 == 0 else (*pop, 205)
        col2 = (*pop, 235) if i % 2 == 0 else (*accent, 235)
        try:
            fn(odraw, cx, cy, r, col1, col2)
        except Exception:
            odraw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col1)

    # ---- 5. thin corner frame accents — a small finishing touch that
    # reads as "designed", not generated ----
    L = int(SLIDE_WIDTH * 0.07)
    m = int(SLIDE_WIDTH * 0.045)
    frame_color = (*_hex_to_rgb(palette["text"]), 90)
    corners = [(m, m, 1, 1), (SLIDE_WIDTH - m, m, -1, 1),
               (m, SLIDE_HEIGHT - m, 1, -1), (SLIDE_WIDTH - m, SLIDE_HEIGHT - m, -1, -1)]
    for cx0, cy0, sx, sy in corners:
        odraw.line([cx0, cy0, cx0 + sx * L, cy0], fill=frame_color, width=4)
        odraw.line([cx0, cy0, cx0, cy0 + sy * L], fill=frame_color, width=4)

    img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
    return img


# ============================================================
# COMFYUI — carousel-specific workflow
# ============================================================
# Deliberately does NOT call image_agent.generate_image()/queue_prompt():
# those hardcode image_agent.NEGATIVE_PROMPT, which is written for the
# VIDEO pipeline's photographic style and explicitly negative-prompts
# AGAINST "flat graphic design, vector art, icon, symbol, solid color
# background" — precisely the premium-illustration look this pipeline
# wants, so reusing it would make ComfyUI fight its own carousel prompt.
# Instead this builds its own minimal SDXL workflow graph and submits it
# with carousel_design_brief.CAROUSEL_NEGATIVE_PROMPT, reusing only
# image_agent.py's low-level, generic HTTP helpers (_post_json,
# wait_for_completion, download_image) read-only — image_agent.py itself
# is never modified, so the video/ebook pipelines are unaffected.

def _carousel_comfy_workflow(prompt_text: str, filename_prefix: str, seed: int, width: int, height: int) -> Dict[str, Any]:
    return {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": _ia.CHECKPOINT_NAME}},
        "2": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt_text, "clip": ["1", 1]}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": CAROUSEL_NEGATIVE_PROMPT, "clip": ["1", 1]}},
        "4": {"class_type": "EmptyLatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
        "5": {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed,
                "steps": _ia.STEPS,
                "cfg": _ia.CFG,
                "sampler_name": _ia.SAMPLER,
                "scheduler": _ia.SCHEDULER,
                "denoise": 1.0,
                "model": ["1", 0],
                "positive": ["2", 0],
                "negative": ["3", 0],
                "latent_image": ["4", 0],
            },
        },
        "6": {"class_type": "VAEDecode", "inputs": {"samples": ["5", 0], "vae": ["1", 2]}},
        "7": {"class_type": "SaveImage", "inputs": {"filename_prefix": filename_prefix, "images": ["6", 0]}},
    }


def _generate_via_carousel_comfy(prompt_text: str, filename_prefix: str, out_path: Path, width: int, height: int, retries: int = 2) -> Path:
    last_error: Optional[Exception] = None
    for attempt in range(retries + 1):
        try:
            _ia.require_comfy()
            seed = int(uuid.uuid4().int % (2 ** 32))
            workflow = _carousel_comfy_workflow(prompt_text, filename_prefix, seed, width, height)
            result = _ia._post_json(f"{_ia.COMFY_URL}/prompt", {"prompt": workflow})
            prompt_id = result.get("prompt_id")
            if not prompt_id:
                raise RuntimeError(f"ComfyUI did not return prompt_id: {result}")
            images = _ia.wait_for_completion(prompt_id)
            if not images:
                raise RuntimeError("ComfyUI completed the job but returned no images.")
            image_bytes = _ia.download_image(images[0])
            if not image_bytes:
                raise RuntimeError("ComfyUI returned an empty image.")
            out_path.parent.mkdir(parents=True, exist_ok=True)
            with out_path.open("wb") as f:
                f.write(image_bytes)
            if not out_path.exists() or out_path.stat().st_size < 10_000:
                raise RuntimeError(f"Generated image appears invalid: {out_path}")
            return out_path
        except Exception as exc:
            last_error = exc
            if attempt < retries:
                logger.warning(f"Carousel ComfyUI generation attempt {attempt + 1} failed: {exc} — retrying")
                time.sleep(3)
    raise RuntimeError(f"Carousel ComfyUI generation failed for '{filename_prefix}': {last_error}") from last_error


def generate_background(
    vertical: str,
    slide_role: str,
    palette: Dict[str, str],
    out_path: Path,
    topic: str = "",
    slide: Optional[Dict[str, Any]] = None,
    market_keywords: Optional[List[str]] = None,
) -> Path:
    """
    Content-aware: builds the prompt/objects from the ACTUAL slide's
    headline/body (and, when available, real market-search result titles
    from carousel_niche_agent.py's market_signal_check) — not a generic
    per-vertical backdrop — so different slides in the same carousel get
    different, relevant imagery instead of one recycled abstract graphic.
    """
    icon_names = pick_icon_names(vertical, topic=topic, slide=slide, market_keywords=market_keywords, max_icons=5)

    if HAS_IMAGE_AGENT:
        try:
            _ia.require_comfy()
            headline = (slide or {}).get("headline", "")
            body = (slide or {}).get("body") or (slide or {}).get("subheadline") or ""
            subject_line = f' The illustration should depict: "{headline}"' + (f' — {body}.' if body else ".") if headline else ""
            objects_phrase = _icon_prompt_phrase(icon_names)
            prompt = (
                f"Premium graphic-design social-media background illustration for the topic "
                f"\"{topic}\".{subject_line} Include {objects_phrase} as clear, recognizable, "
                f"colorful graphic-design elements arranged around the edges of the frame. "
                f"Brand colors: base {palette['bg_from']}, accent {palette['accent']}, "
                f"highlight {palette.get('pop', palette['accent'])} — use them boldly and "
                f"generously across the whole image. {IMAGE_STYLE_MODIFIERS}"
            )
            out_path.parent.mkdir(parents=True, exist_ok=True)
            _generate_via_carousel_comfy(
                prompt_text=prompt,
                filename_prefix=f"carousel_bg_{slide_role}",
                out_path=out_path,
                width=1024,
                height=1280,
            )
            img = Image.open(out_path).convert("RGB").resize((SLIDE_WIDTH, SLIDE_HEIGHT), Image.LANCZOS)
            img.save(out_path)
            return out_path
        except Exception as e:
            logger.warning(f"ComfyUI background generation failed, using Pillow fallback: {e}")

    seed_key = (slide or {}).get("headline") or topic or slide_role
    img = _pillow_gradient_background(palette, slide_role, icon_names, seed_key=seed_key)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
    return out_path


# ============================================================
# TEXT COMPOSITING
# ============================================================

def _wrap_text(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont, max_width: int) -> List[str]:
    words = text.split()
    lines: List[str] = []
    current = ""
    for w in words:
        trial = f"{current} {w}".strip()
        if draw.textlength(trial, font=font) <= max_width or not current:
            current = trial
        else:
            lines.append(current)
            current = w
    if current:
        lines.append(current)
    return lines


def _draw_multiline(
    draw: ImageDraw.ImageDraw, lines: List[str], font: ImageFont.ImageFont,
    x: int, y: int, fill: Tuple[int, int, int], line_spacing: float = 1.15, anchor_center_x: Optional[int] = None,
) -> int:
    ascent, descent = font.getmetrics()
    line_height = int((ascent + descent) * line_spacing)
    for line in lines:
        draw_x = x
        if anchor_center_x is not None:
            w = draw.textlength(line, font=font)
            draw_x = int(anchor_center_x - w / 2)
        draw.text((draw_x, y), line, font=font, fill=fill)
        y += line_height
    return y


def _block_height(lines: List[str], font: ImageFont.ImageFont, line_spacing: float = 1.15) -> int:
    ascent, descent = font.getmetrics()
    return int((ascent + descent) * line_spacing) * max(len(lines), 1)


def _apply_text_scrim(
    img: Image.Image, box: Tuple[float, float, float, float], text_color: Tuple[int, int, int],
    base_rgb: Optional[Tuple[int, int, int]] = None,
) -> Image.Image:
    """
    Now that backgrounds are deliberately bold/saturated (per explicit
    feedback that muted gradients weren't premium), text needs its own
    contrast layer instead of relying on a dulled-down background — a
    real premium-template pattern (a soft rounded scrim panel behind the
    copy block), not a hack. The panel is tinted from the vertical's own
    brand base color (darkened for light text, lightened for dark text)
    instead of flat black/white, so it reads as "on-brand", not a generic
    gray box dropped on top of the art.
    """
    luminance = 0.299 * text_color[0] + 0.587 * text_color[1] + 0.114 * text_color[2]
    base = base_rgb or (20, 22, 30)
    if luminance > 140:
        scrim_rgb = tuple(max(0, int(c * 0.30)) for c in base)
    else:
        scrim_rgb = tuple(min(255, int(c + (255 - c) * 0.88)) for c in base)
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    x0, y0, x1, y1 = box
    od.rounded_rectangle([x0, y0, x1, y1], radius=28, fill=(*scrim_rgb, 128))
    return Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")


def composite_slide(
    background_path: Path, slide: Dict[str, Any], slide_role: str, palette: Dict[str, str], out_path: Path,
) -> Path:
    img = Image.open(background_path).convert("RGB")
    if img.size != (SLIDE_WIDTH, SLIDE_HEIGHT):
        img = img.resize((SLIDE_WIDTH, SLIDE_HEIGHT), Image.LANCZOS)
    text_color = _hex_to_rgb(palette["text"])
    accent_color = _hex_to_rgb(palette["accent"])
    margin = int(SLIDE_WIDTH * 0.09)
    content_width = SLIDE_WIDTH - 2 * margin
    pad = 28

    # measure text (on a throwaway draw context) BEFORE placing the scrim,
    # so the scrim's height is real, not guessed
    meas = ImageDraw.Draw(img)

    if slide_role == "hook":
        headline_font = get_font("headline", 92)
        sub_font = get_font("body", 42)
        lines = _wrap_text(meas, slide.get("headline", ""), headline_font, content_width)
        sub_lines = _wrap_text(meas, slide.get("subheadline", ""), sub_font, content_width)
        y0 = int(SLIDE_HEIGHT * 0.38)
        h = _block_height(lines, headline_font) + 20 + _block_height(sub_lines, sub_font)
        img = _apply_text_scrim(img, (margin - pad, y0 - pad, SLIDE_WIDTH - margin + pad, y0 + h + pad), text_color, base_rgb=_hex_to_rgb(palette["bg_from"]))
        draw = ImageDraw.Draw(img)
        y = _draw_multiline(draw, lines, headline_font, margin, y0, text_color)
        y += 20
        _draw_multiline(draw, sub_lines, sub_font, margin, y, accent_color)
        # small "swipe" affordance, standard carousel convention
        hint_font = get_font("body", 32)
        hint_y = SLIDE_HEIGHT - 90
        img = _apply_text_scrim(img, (margin - pad, hint_y - 10, margin + 220, hint_y + 46), text_color, base_rgb=_hex_to_rgb(palette["bg_from"]))
        draw = ImageDraw.Draw(img)
        draw.text((margin, hint_y), "Swipe  →", font=hint_font, fill=accent_color)

    elif slide_role == "cta":
        headline_font = get_font("headline", 76)
        body_font = get_font("body", 40)
        cta_font = get_font("headline", 46)
        lines = _wrap_text(meas, slide.get("headline", ""), headline_font, content_width)
        body_lines = _wrap_text(meas, slide.get("body", ""), body_font, content_width)
        cta_lines = _wrap_text(meas, slide.get("cta_text", ""), cta_font, content_width)
        y0 = int(SLIDE_HEIGHT * 0.30)
        h = (_block_height(lines, headline_font) + 16 + _block_height(body_lines, body_font)
             + 50 + _block_height(cta_lines, cta_font))
        img = _apply_text_scrim(img, (margin - pad, y0 - pad, SLIDE_WIDTH - margin + pad, y0 + h + pad), text_color, base_rgb=_hex_to_rgb(palette["bg_from"]))
        draw = ImageDraw.Draw(img)
        y = _draw_multiline(draw, lines, headline_font, margin, y0, text_color)
        y += 16
        y = _draw_multiline(draw, body_lines, body_font, margin, y, text_color)
        y += 50
        _draw_multiline(draw, cta_lines, cta_font, margin, y, accent_color)

    else:  # content slide
        headline_font = get_font("headline", 68)
        body_font = get_font("body", 40)
        badge_font = get_font("headline", 34)
        lines = _wrap_text(meas, slide.get("headline", ""), headline_font, content_width)
        body_lines = _wrap_text(meas, slide.get("body", ""), body_font, content_width)
        y0 = margin + 110
        h = _block_height(lines, headline_font) + 24 + _block_height(body_lines, body_font)
        img = _apply_text_scrim(img, (margin - pad, y0 - pad, SLIDE_WIDTH - margin + pad, y0 + h + pad), text_color, base_rgb=_hex_to_rgb(palette["bg_from"]))
        draw = ImageDraw.Draw(img)

        # small numbered badge, standard step-by-step/checklist convention —
        # solid filled chip (not just an outline) so it stays legible on a
        # bold, colorful background
        badge_text = f"{slide.get('slide_number', '')}".zfill(2)
        draw.ellipse([margin, margin, margin + 70, margin + 70], fill=(*accent_color, 255))
        bw = draw.textlength(badge_text, font=badge_font)
        badge_text_color = (8, 9, 14) if (0.299 * accent_color[0] + 0.587 * accent_color[1] + 0.114 * accent_color[2]) > 140 else (255, 255, 255)
        draw.text((margin + 35 - bw / 2, margin + 16), badge_text, font=badge_font, fill=badge_text_color)

        y = _draw_multiline(draw, lines, headline_font, margin, y0, text_color)
        y += 24
        _draw_multiline(draw, body_lines, body_font, margin, y, text_color)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path, quality=95)
    return out_path


# ============================================================
# EDITABLE HTML EXPORT
# ============================================================
# The most robust "editable" guarantee in this whole pipeline: real CSS
# text nodes, not an image. Opens in any browser; every headline/body
# string is a normal, selectable, directly-editable HTML element. No
# dependency on Pillow, fonts, or ComfyUI to remain editable later.

_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{title} — Editable Carousel</title>
<style>
  body {{ margin: 0; padding: 24px; background: #e9e9ec; font-family: -apple-system, "Segoe UI", Arial, sans-serif; }}
  .meta {{ max-width: 1080px; margin: 0 auto 24px; padding: 16px 20px; background: white; border-radius: 8px; }}
  .meta h1 {{ margin: 0 0 6px; font-size: 20px; }}
  .meta p {{ margin: 4px 0; color: #444; font-size: 14px; }}
  .slide {{
    width: 1080px; height: 1350px; margin: 0 auto 32px; position: relative;
    background: linear-gradient(135deg, {bg_from}, {bg_to});
    color: {text_color}; overflow: hidden; border-radius: 12px;
    box-shadow: 0 4px 24px rgba(0,0,0,0.15);
  }}
  .slide .inner {{ position: absolute; left: 9%; right: 9%; }}
  .hook .inner {{ top: 38%; }}
  .content .inner {{ top: 10%; }}
  .cta .inner {{ top: 30%; }}
  .badge {{
    display: inline-flex; align-items: center; justify-content: center;
    width: 64px; height: 64px; border: 3px solid {accent}; border-radius: 50%;
    color: {accent}; font-weight: 700; font-size: 26px; margin-bottom: 24px;
  }}
  h2 {{ font-size: 58px; line-height: 1.15; font-weight: 700; margin: 0 0 16px;
        outline: none; }}
  .hook h2 {{ font-size: 66px; }}
  .subheadline, .body-text {{ font-size: 32px; line-height: 1.35; color: {accent}; margin: 0; outline: none; }}
  .content .body-text {{ color: {text_color}; margin-top: 18px; }}
  .cta .body-text {{ color: {text_color}; }}
  .cta-text {{ font-size: 36px; font-weight: 700; color: {accent}; margin-top: 40px; outline: none; }}
  .swipe-hint {{ position: absolute; bottom: 6%; left: 9%; color: {accent}; font-size: 26px; }}
  [contenteditable="true"] {{ cursor: text; }}
  [contenteditable="true"]:hover {{ outline: 1px dashed rgba(255,255,255,0.4); }}
</style>
</head>
<body>
<div class="meta">
  <h1>{title}</h1>
  <p><strong>Vertical:</strong> {vertical} &nbsp;|&nbsp; <strong>Framework:</strong> {framework}</p>
  <p>Every headline/body below is a normal editable HTML element (contenteditable) —
     click any text and type to edit. This is the source of truth alongside
     slides_content.json; the rendered PNGs are generated from that JSON, not this file,
     so re-run carousel_design_agent.py after editing the JSON to regenerate matching PNGs.</p>
  <p><strong>Caption:</strong> {caption}</p>
  <p><strong>Hashtags:</strong> {hashtags}</p>
</div>
{slides_html}
</body>
</html>
"""


def render_carousel_html(manuscript: Dict[str, Any], palette: Dict[str, str], out_path: Path) -> Path:
    slides_html_parts: List[str] = []
    slides = manuscript.get("slides", [])
    for i, slide in enumerate(slides):
        if i == 0:
            role_class = "hook"
            inner = (
                f'<h2 contenteditable="true">{slide.get("headline", "")}</h2>'
                f'<p class="subheadline" contenteditable="true">{slide.get("subheadline", "")}</p>'
            )
            extra = '<div class="swipe-hint">Swipe →</div>'
        elif i == len(slides) - 1:
            role_class = "cta"
            inner = (
                f'<h2 contenteditable="true">{slide.get("headline", "")}</h2>'
                f'<p class="body-text" contenteditable="true">{slide.get("body", "")}</p>'
                f'<p class="cta-text" contenteditable="true">{slide.get("cta_text", "")}</p>'
            )
            extra = ""
        else:
            role_class = "content"
            badge = f'<div class="badge">{str(slide.get("slide_number", i + 1)).zfill(2)}</div><br>'
            inner = (
                f'{badge}'
                f'<h2 contenteditable="true">{slide.get("headline", "")}</h2>'
                f'<p class="body-text" contenteditable="true">{slide.get("body", "")}</p>'
            )
            extra = ""
        slides_html_parts.append(
            f'<div class="slide {role_class}"><div class="inner">{inner}</div>{extra}</div>'
        )

    html = _HTML_TEMPLATE.format(
        title=manuscript.get("title", ""),
        vertical=manuscript.get("vertical", ""),
        framework=manuscript.get("framework", ""),
        caption=manuscript.get("caption", "").replace("\n", "<br>"),
        hashtags=" ".join(f"#{h}" for h in manuscript.get("hashtags", [])),
        bg_from=palette["bg_from"], bg_to=palette["bg_to"],
        text_color=palette["text"], accent=palette["accent"],
        slides_html="\n".join(slides_html_parts),
    )
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")
    return out_path
