"""
CAROUSEL DESIGN BRIEF
=======================

Encodes what live 2026 research into the Instagram-carousel-template
marketplace (Etsy/Creative Market listings, IG best-practice guides) says
actually sells and actually performs — the same role housing_content_brief.py
plays for the housing pipeline: a fixed, documented set of parameters the
generation pipeline follows, so "what good looks like" isn't re-decided (or
forgotten) on every run.

IMPORTANT — this captures PATTERNS, not any specific paid product: slide
counts, dimensions, typography/color-count rules, and proven content
frameworks (PAS, AIDA, step-by-step, utility). Nothing here is a specific
seller's actual artwork, copy, or brand — carousel_content_agent.py and
carousel_design_agent.py always generate original content/art from these
principles, never reproduce a particular listing.

Sources (fetched live, see chat for full citations):
  - metricool.com/instagram-carousels/  (dimensions, slide limits, hook/CTA)
  - postnitro.ai/blog/post/instagram-carousel-post  (frameworks, slide-count
    sweet spot, typography/branding consistency)
"""

from __future__ import annotations

from typing import Dict, List

# ---- Dimensions ----
# 1080x1350 (4:5 portrait) takes the most vertical feed space of the three
# IG-supported ratios (1.91:1 landscape, 1:1 square, 4:5 portrait) — the
# consistent recommendation across every 2026 source checked.
SLIDE_WIDTH = 1080
SLIDE_HEIGHT = 1350

# ---- Slide count ----
# "the sweet spot for engagement landing between 8 to 10 slides" for
# educational/how-to content; 3-5 for a quick announcement. Default to the
# engagement sweet spot since these are meant to be premium, substantial
# products, not quick announcements.
MIN_SLIDES = 8
MAX_SLIDES = 10
ANNOUNCEMENT_SLIDES = 4  # used only if a future content type wants it

# ---- Typography / branding discipline ----
# "Limit to two fonts maximum — one for headlines, one for body copy" and
# "Maintain a defined brand color scheme across all slides" — both are
# treated as hard rules in carousel_design_agent.py, not suggestions.
MAX_FONTS = 2

# ---- Proven content frameworks ----
# Each carousel picks ONE framework and structures every content slide
# around it — mixing frameworks inside one carousel is what makes DIY
# carousels look amateurish; premium ones commit to a structure.
CONTENT_FRAMEWORKS = {
    "problem_agitation_solution": (
        "Slide 1 names a specific, painful problem the target buyer "
        "recognizes immediately. The next 2-3 slides agitate it (why it's "
        "worse than they think, what it's costing them). The remaining "
        "slides deliver the solution step by step. Ends on a clear "
        "next-action CTA slide."
    ),
    "aida": (
        "Attention (a bold, specific hook slide) -> Interest (a surprising "
        "fact or reframe) -> Desire (what life/business looks like once "
        "this is solved, made concrete and specific) -> Action (one clear "
        "CTA slide). Best for offer/promo-style carousels."
    ),
    "step_by_step": (
        "Slide 1 promises a specific outcome and states the number of "
        "steps. Each following slide is exactly one numbered step, one "
        "idea per slide, in strict order. Last slide recaps all steps in "
        "one glance plus a CTA."
    ),
    "utility_checklist": (
        "A savable/shareable reference: a checklist, a myth-vs-fact list, "
        "or a 'signs you need X' list. Slide 1 states what the list is and "
        "why it's worth saving. Each item gets its own slide. Last slide "
        "is a CTA plus 'save this for later'."
    ),
}

# ---- Premium client verticals ----
# Who actually pays real money (not $2-3 Etsy impulse buys) for a
# professionally designed, on-brand carousel template pack. Mirrors
# ebook_topic_agent.py's SKILL_PILLARS pattern — these seed Ollama's
# brainstorming, edit freely.
PREMIUM_CLIENT_VERTICALS = {
    "business_coaches_consultants": (
        "solo consultants and coaches selling high-ticket offers "
        "(coaching programs, masterminds, done-for-you services) who need "
        "carousels that look like a real agency made them"
    ),
    "real_estate_agents": (
        "real estate agents and small brokerages needing listing "
        "carousels, market-update carousels, and buyer/seller education "
        "carousels with a polished, trustworthy look"
    ),
    "wellness_medspa": (
        "boutique wellness studios, med-spas, and high-end fitness "
        "studios needing premium, calm, editorial-style carousels for "
        "services and client education"
    ),
    "financial_and_legal_advisors": (
        "financial advisors, accountants, and small legal practices "
        "needing carousels that read as authoritative and trustworthy, "
        "not salesy or templated-looking"
    ),
    "boutique_hospitality": (
        "independent restaurants, cafes, and boutique hotels needing "
        "menu/offer/story carousels with a distinct, premium brand feel"
    ),
    "interior_design_and_home": (
        "interior designers, architects, and home-renovation "
        "professionals needing portfolio and process carousels that "
        "showcase craft and taste"
    ),
}

DEFAULT_MIN_SLIDES_KEY = "MIN_SLIDES"

# ============================================================
# CONTENT-AWARE IMAGERY — added in response to explicit feedback that the
# original abstract-gradient-plus-circle background wasn't "premium": every
# background should now (a) be more colorful, (b) contain real objects/icons
# instead of bare geometric accents, and (c) reflect what the SPECIFIC slide
# is actually about, not just the vertical.
#
# This is still 100% original, generated-per-run art — no traced icon set,
# no scraped reference images. ICON_KEYWORD_MAP just tells the pipeline
# which simple, hand-drawn-in-code vector icon (see carousel_design_agent.py)
# or ComfyUI prompt phrase best matches words that actually showed up in a
# slide's own headline/body, so "generate images on contents" is real,
# not decorative.
# ============================================================

# Rough keyword -> icon-concept map. Substring match against the slide's own
# lowercased headline+body (and, when available, real market-search result
# titles from carousel_niche_agent.py's market_signal_check) — not a fixed
# per-vertical default, so different slides in the same carousel can pull
# different, relevant icons.
ICON_KEYWORD_MAP: Dict[str, str] = {
    "growth": "chart_bar", "revenue": "chart_bar", "sales": "chart_bar",
    "profit": "chart_bar", "results": "chart_bar", "roi": "chart_bar",
    "idea": "lightbulb", "innovat": "lightbulb", "strategy": "lightbulb",
    "insight": "lightbulb", "smart": "lightbulb",
    "home": "house", "listing": "house", "property": "house",
    "real estate": "house", "buyer": "house", "seller": "house",
    "love": "heart", "client": "heart", "care": "heart", "wellness": "heart",
    "health": "heart", "calm": "heart", "relax": "heart",
    "system": "gear", "process": "gear", "automat": "gear",
    "workflow": "gear", "efficien": "gear",
    "time": "clock", "schedule": "clock", "deadline": "clock",
    "fast": "clock", "minute": "clock", "quick": "clock",
    "goal": "target", "focus": "target", "aim": "target", "precise": "target",
    "check": "check", "step": "check", "done": "check", "complete": "check",
    "mistake": "check", "fix": "check",
    "energy": "spark", "power": "spark", "boost": "spark", "bold": "spark",
    "natural": "leaf", "organic": "leaf", "sustain": "leaf", "fresh": "leaf",
    "star": "star", "premium": "star", "best": "star", "top": "star",
    "luxury": "star", "elite": "star",
    "up": "arrow_up", "increase": "arrow_up", "rise": "arrow_up",
    "scale": "arrow_up", "grow": "arrow_up",
    "menu": "cup", "restaurant": "cup", "cafe": "cup", "hospitality": "cup",
    "design": "brush", "interior": "brush", "renovat": "brush", "decor": "brush",
    "money": "coin", "financial": "coin", "invest": "coin", "budget": "coin",
    "legal": "coin", "advisor": "coin",
}

# Fallback icon set per vertical, used only when no keyword in a slide's own
# text matches anything above — keeps every slide on-topic even when a slide
# is short (e.g. a hook or CTA with little literal text to match against).
DEFAULT_ICONS_BY_VERTICAL: Dict[str, List[str]] = {
    "business_coaches_consultants": ["chart_bar", "target", "lightbulb"],
    "real_estate_agents": ["house", "chart_bar", "check"],
    "wellness_medspa": ["leaf", "heart", "spark"],
    "financial_and_legal_advisors": ["coin", "chart_bar", "check"],
    "boutique_hospitality": ["cup", "star", "spark"],
    "interior_design_and_home": ["house", "brush", "star"],
}

# Short, plain-English object phrases the ComfyUI prompt builder uses so the
# generated image actually contains the concrete object implied by the icon
# concept, instead of an abstract shape.
ICON_PROMPT_PHRASES: Dict[str, str] = {
    "chart_bar": "a rising bar chart with an upward trend arrow",
    "lightbulb": "a glowing lightbulb radiating small spark lines",
    "house": "a friendly modern house with an open door",
    "heart": "a warm rounded heart shape with soft sparkles around it",
    "gear": "a pair of interlocking gears next to a checklist",
    "clock": "a stylized clock face with motion streaks",
    "target": "a bullseye target with an arrow at the center",
    "check": "a bold checkmark with a few confetti pieces",
    "spark": "an energetic lightning bolt with small stars",
    "leaf": "a fresh leaf with a gentle organic swirl",
    "star": "a bold five-point star with a sparkle trail",
    "arrow_up": "an upward-trending arrow with small dots trailing behind it",
    "cup": "a steaming coffee cup beside a small plate",
    "brush": "a paintbrush and a color swatch chip",
    "coin": "a stack of coins with a small upward arrow",
}

# Dropped into every ComfyUI background prompt — this is the direct answer
# to "more colorful", "more premium", "a bit funny, graphic, good vibes":
# real color and real objects, not a flat gradient box.
IMAGE_STYLE_MODIFIERS = (
    "vibrant colorful premium modern flat illustration style, playful and "
    "inviting mood with a touch of good-natured humor, rich saturated "
    "multi-color palette, confident bold shapes, energetic and dynamic "
    "composition, professional editorial-illustration quality, generous "
    "clear negative space reserved for text overlay, no text, no letters, "
    "no words, no logos, no watermarks, no real people, no human faces, "
    "not photorealistic"
)

# image_agent.py's shared NEGATIVE_PROMPT is written for the VIDEO pipeline's
# photographic style — it actively negative-prompts AGAINST "flat graphic
# design, vector art, icon, symbol, solid color background", which is
# exactly the premium-illustration look this carousel pipeline wants. Using
# it here would fight the carousel's own prompt. So carousel_design_agent.py
# submits its own ComfyUI workflow (reusing image_agent.py's low-level HTTP
# helpers read-only — never modifying that file) with THIS negative prompt
# instead, tuned for flat colorful illustration rather than photography.
CAROUSEL_NEGATIVE_PROMPT = (
    "text, words, letters, typography, caption, subtitle, title, watermark, "
    "logo, signature, low quality, blurry, jpeg artifacts, muddy colors, "
    "dull colors, washed out, desaturated, grayscale, monochrome, "
    "photorealistic, photograph, real photo, realistic human, human face, "
    "human skin, 3d render, cluttered, cropped, out of frame, ugly, "
    "amateur, low contrast, dark and gloomy, empty background, plain "
    "background, boring background"
)
