@echo off
cd /d "%~dp0"
set "PYTHON_EXE=python"
%PYTHON_EXE% carousel_loop_agent.py pause
pause
