"""
CAROUSEL LOOP AGENT
======================

Runs carousel_master_agent.py's pipeline forever: pick a niche, write
the manuscript (chunked + quality-refined), render, assemble the folder,
wait, repeat — until you send a stop command. Mirrors ebook_loop_agent.py
/ video_loop_agent.py's pause/resume/stop control-file pattern so it
behaves consistently with the rest of this project.

Uses its own state/command files under data/carousel/ — running this
alongside ebook_loop_agent.py and/or video_loop_agent.py at the same time
is safe, they never read or write each other's files.

Usage:
    python ai/carousel_loop_agent.py run
    python ai/carousel_loop_agent.py status
    python ai/carousel_loop_agent.py pause
    python ai/carousel_loop_agent.py resume
    python ai/carousel_loop_agent.py stop
"""

from __future__ import annotations

import argparse
import json
import logging
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _carousel_bootstrap import PROJECT_ROOT  # noqa: E402 — resolves ai/ + project root regardless of subfolder placement

from carousel_master_agent import run_carousel_pipeline

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("carousel_loop_agent")

BASE_DIR = PROJECT_ROOT
DATA_DIR = BASE_DIR / "data" / "carousel"
DATA_DIR.mkdir(parents=True, exist_ok=True)

STATE_FILE = DATA_DIR / "loop_state.json"
COMMAND_FILE = DATA_DIR / "loop_command.json"

# Carousel generation (chunked content + a second refine pass, then
# rendering) already takes real time — this is mostly a courtesy pause,
# same rationale as ebook_loop_agent.py's LOOP_DELAY_SECONDS.
LOOP_DELAY_SECONDS = 60

REFINE = True  # the quality/critique pass — set False only for quick tests


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_state() -> dict:
    if not STATE_FILE.exists():
        return {
            "status": "idle",
            "total_generated": 0,
            "last_title": None,
            "last_run_at": None,
            "last_error": None,
        }
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"status": "unknown"}


def save_state(state: dict) -> None:
    STATE_FILE.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


def send_command(cmd: str) -> None:
    COMMAND_FILE.write_text(json.dumps({"command": cmd, "sent_at": _now()}), encoding="utf-8")
    print(f"✓ Sent command: {cmd}")


def read_command() -> Optional[str]:
    if not COMMAND_FILE.exists():
        return None
    try:
        return json.loads(COMMAND_FILE.read_text(encoding="utf-8")).get("command")
    except Exception:
        return None


def clear_command() -> None:
    COMMAND_FILE.unlink(missing_ok=True)


def run_one_job(state: dict) -> dict:
    print(f"\n{'='*70}\n🎠  Starting new carousel job\n{'='*70}")
    try:
        result = run_carousel_pipeline(refine=REFINE)
        state["total_generated"] += 1
        state["last_title"] = result.get("title")
        state["last_folder"] = result.get("folder")
        state["last_slide_count"] = result.get("slide_count")
        state["last_run_at"] = _now()
        state["last_error"] = None
        state["status"] = "running"
    except Exception as e:
        logger.error(f"Job failed: {e}\n{traceback.format_exc()}")
        state["last_error"] = str(e)
        state["last_run_at"] = _now()
        state["status"] = "running"  # one bad job shouldn't kill the loop

    save_state(state)
    return state


def controlled_wait(seconds: int) -> str:
    waited = 0
    while waited < seconds:
        cmd = read_command()
        if cmd in ("stop", "pause"):
            return cmd
        time.sleep(min(5, seconds - waited))
        waited += 5
    return "continue"


def run_loop():
    state = load_state()
    state["status"] = "running"
    save_state(state)

    print("\n" + "=" * 70)
    print("🎠  CAROUSEL LOOP AGENT — running until stopped")
    print("=" * 70)
    print(f"Delay between carousels : {LOOP_DELAY_SECONDS}s")
    print(f"Quality refine pass     : {REFINE}")
    print("Send commands from another terminal:")
    print("  python ai/carousel_loop_agent.py pause")
    print("  python ai/carousel_loop_agent.py resume")
    print("  python ai/carousel_loop_agent.py stop")
    print("=" * 70)

    while True:
        cmd = read_command()

        if cmd == "stop":
            clear_command()
            state["status"] = "stopped"
            save_state(state)
            print("\n🛑 Stop command received. Exiting loop.")
            break

        if cmd == "pause":
            state["status"] = "paused"
            save_state(state)
            print("\n⏸  Paused. Waiting for resume/stop command...")
            while True:
                cmd2 = read_command()
                if cmd2 == "resume":
                    clear_command()
                    state["status"] = "running"
                    save_state(state)
                    print("▶  Resumed.")
                    break
                if cmd2 == "stop":
                    clear_command()
                    state["status"] = "stopped"
                    save_state(state)
                    print("🛑 Stop command received while paused. Exiting loop.")
                    return
                time.sleep(3)
            continue

        state = run_one_job(state)

        outcome = controlled_wait(LOOP_DELAY_SECONDS)
        if outcome == "stop":
            clear_command()
            state["status"] = "stopped"
            save_state(state)
            print("\n🛑 Stop command received. Exiting loop.")
            break


def show_status():
    state = load_state()
    print("\n" + "=" * 70)
    print("CAROUSEL LOOP STATUS")
    print("=" * 70)
    for k, v in state.items():
        print(f"{k:20s}: {v}")
    print("=" * 70)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["run", "status", "pause", "resume", "stop"])
    args = ap.parse_args()

    if args.action == "run":
        run_loop()
    elif args.action == "status":
        show_status()
    else:
        send_command(args.action)


if __name__ == "__main__":
    main()
