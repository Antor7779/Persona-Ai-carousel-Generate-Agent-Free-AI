"""
CAROUSEL CONTENT AGENT
=========================

Writes the actual EDITABLE slide-by-slide copy for one carousel, built in
the same "one focused LLM call per piece, not one giant prompt" style
ebook_writer_agent.py uses for chapters — quality over speed, deliberately:

    hook slide  ->  content slides (one call each, aware of what came
    before so nothing repeats)  ->  CTA slide  ->  caption + hashtags
        |
        v
    a SECOND critique-and-tighten pass over every slide (this is the real
    mechanism behind "take more time, make it better" — an actual extra
    reasoning pass, not a fake delay)
        |
        v
    one merged, chunked JSON manuscript — this JSON *is* the editable
    source of truth; carousel_design_agent.py only ever reads from it.

Every slide's text is generated as data (headline/body strings), never
baked into an image at this stage — that split is what makes the final
product genuinely editable instead of a flattened, un-editable picture.
"""

from __future__ import annotations

import logging
import random
from pathlib import Path
from typing import Any, Dict, List

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _carousel_bootstrap import PROJECT_ROOT  # noqa: E402,F401 — resolves ai/ + project root regardless of subfolder placement

from seo_agent import ask_ollama, extract_json, clean_text, now_iso  # noqa: E402
from carousel_design_brief import CONTENT_FRAMEWORKS, MIN_SLIDES, MAX_SLIDES  # noqa: E402

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("carousel_content_agent")


def _ask_json(prompt: str, fallback: Dict[str, Any]) -> Dict[str, Any]:
    raw = ask_ollama(prompt)
    if not raw:
        return fallback
    try:
        return extract_json(raw)
    except Exception as e:
        logger.warning(f"JSON parse failed, using fallback: {e}")
        return fallback


# ============================================================
# STEP 1: HOOK SLIDE
# ============================================================

def generate_hook_slide(title: str, pitch: str, vertical: str, framework: str) -> Dict[str, str]:
    framework_brief = CONTENT_FRAMEWORKS.get(framework, "")
    prompt = f"""
You are writing SLIDE 1 (the hook/cover) of a premium Instagram carousel
for: {vertical.replace('_', ' ')}

Carousel title: {title}
Pitch: {pitch}
Framework this carousel follows: {framework} — {framework_brief}

Slide 1's ONLY job is to stop the scroll and make the exact right buyer
recognize themselves in one glance. Bold, specific, zero fluff.

Return ONLY this JSON:
{{
  "headline": "under 8 words, bold, specific — the hook itself",
  "subheadline": "one short supporting line, under 14 words"
}}
"""
    data = _ask_json(prompt, {"headline": title, "subheadline": pitch[:80]})
    return {
        "headline": clean_text(data.get("headline", title)),
        "subheadline": clean_text(data.get("subheadline", pitch))[:120],
    }


# ============================================================
# STEP 2: CONTENT SLIDES (one Ollama call per slide)
# ============================================================

def generate_content_slides(
    title: str, pitch: str, framework: str, num_slides: int
) -> List[Dict[str, Any]]:
    framework_brief = CONTENT_FRAMEWORKS.get(framework, "")
    slides: List[Dict[str, Any]] = []
    prior_headlines: List[str] = []

    for i in range(1, num_slides + 1):
        prior_block = (
            "\nPrior slide headlines (do not repeat these ideas):\n"
            + "\n".join(f"- {h}" for h in prior_headlines)
            if prior_headlines else ""
        )
        prompt = f"""
You are writing SLIDE {i + 1} of {num_slides + 2} of a premium Instagram
carousel (slide 1 is the hook, already written; the final slide is the
CTA, written separately). This carousel follows the {framework} framework:
{framework_brief}

Carousel title: {title}
Pitch: {pitch}
{prior_block}

This is content slide {i} of {num_slides}. ONE idea only — do not cram
multiple points onto this slide. Write for someone swiping fast: short,
concrete, no filler words, no generic advice.

Return ONLY this JSON:
{{
  "headline": "under 10 words, the one idea for this slide",
  "body": "1-3 short sentences expanding it, concrete not vague"
}}
"""
        fallback = {"headline": f"{title} — part {i}", "body": pitch}
        data = _ask_json(prompt, fallback)
        headline = clean_text(data.get("headline", fallback["headline"]))
        body = clean_text(data.get("body", fallback["body"]))
        slides.append({"slide_number": i + 1, "headline": headline, "body": body})
        prior_headlines.append(headline)
        print(f"  ✍  Slide {i + 1}: {headline}")

    return slides


# ============================================================
# STEP 3: CTA SLIDE
# ============================================================

def generate_cta_slide(title: str, vertical: str, last_slide_number: int) -> Dict[str, str]:
    prompt = f"""
You are writing the FINAL slide (a clear call-to-action) of a premium
Instagram carousel titled "{title}" for {vertical.replace('_', ' ')}.

Return ONLY this JSON:
{{
  "headline": "under 8 words, a satisfying close, not just 'thanks'",
  "body": "one line reinforcing the value delivered",
  "cta_text": "under 8 words, one specific action (e.g. 'Save this for your next client call', 'DM me PLAN to get started')"
}}
"""
    fallback = {
        "headline": "Ready to put this into practice?",
        "body": f"That's the full breakdown on {title.lower()}.",
        "cta_text": "Save this post and share it with someone who needs it",
    }
    data = _ask_json(prompt, fallback)
    return {
        "slide_number": last_slide_number,
        "headline": clean_text(data.get("headline", fallback["headline"])),
        "body": clean_text(data.get("body", fallback["body"])),
        "cta_text": clean_text(data.get("cta_text", fallback["cta_text"])),
    }


# ============================================================
# STEP 4: CAPTION + HASHTAGS (posting metadata)
# ============================================================

def generate_caption_and_hashtags(title: str, pitch: str, vertical: str) -> Dict[str, Any]:
    prompt = f"""
Write an Instagram caption + hashtag set for a carousel titled
"{title}" ({pitch}), aimed at {vertical.replace('_', ' ')}.

Return ONLY this JSON:
{{
  "caption": "3-5 short lines, hook first line, ends with a question or soft CTA, no hashtags inside this field",
  "hashtags": ["15-25 relevant hashtags, no # symbol, mix of broad and niche-specific"]
}}
"""
    fallback = {
        "caption": f"{title}\n\nSwipe through, then save this for later.",
        "hashtags": [vertical.replace("_", ""), "smallbusiness", "contentmarketing"],
    }
    data = _ask_json(prompt, fallback)
    hashtags = data.get("hashtags", fallback["hashtags"])
    if isinstance(hashtags, str):
        hashtags = [h.strip().lstrip("#") for h in hashtags.split(",") if h.strip()]
    return {
        "caption": clean_text(data.get("caption", fallback["caption"])),
        "hashtags": [clean_text(h).lstrip("#") for h in hashtags if clean_text(h)],
    }


# ============================================================
# STEP 5: QUALITY PASS — critique and tighten every slide
# ============================================================
# This is the real mechanism behind "don't rush this, take longer and
# make it better": one extra Ollama call per slide that looks at the
# draft with fresh eyes and tightens it, instead of shipping the first
# draft. A slow fake delay would waste time for nothing; this actually
# improves the output.

def refine_slide(slide: Dict[str, Any]) -> Dict[str, Any]:
    headline = slide.get("headline", "")
    body = slide.get("body", "")
    if not headline and not body:
        return slide

    prompt = f"""
Critique and tighten this Instagram carousel slide. It will be read in
under 2 seconds while someone swipes, so it must be as sharp as possible.

Current headline: {headline}
Current body: {body}

Rewrite ONLY if you can make it more specific, more concrete, or shorter
without losing meaning. If it's already tight, return it unchanged.

Return ONLY this JSON:
{{
  "headline": "the final, tightened headline",
  "body": "the final, tightened body (empty string if this slide has no body field)"
}}
"""
    data = _ask_json(prompt, {"headline": headline, "body": body})
    refined = dict(slide)
    refined["headline"] = clean_text(data.get("headline", headline)) or headline
    if "body" in slide:
        new_body = clean_text(data.get("body", body))
        refined["body"] = new_body or body
    return refined


# ============================================================
# ALT TEXT (accessibility + IG SEO — one of the "needed to post" features)
# ============================================================

def generate_alt_text(slide: Dict[str, Any]) -> str:
    headline = slide.get("headline", "")
    body = slide.get("body", "")
    text = f"{headline}. {body}".strip()
    return clean_text(text)[:280] if text else "Carousel slide"


# ============================================================
# ENTRY POINT — build + merge the full chunked manuscript
# ============================================================

def write_carousel_manuscript(
    title: str,
    pitch: str,
    vertical: str,
    framework: str,
    refine: bool = True,
    market_keywords: List[str] | None = None,
) -> Dict[str, Any]:
    num_content_slides = random.randint(MIN_SLIDES, MAX_SLIDES) - 2  # minus hook + CTA
    num_content_slides = max(num_content_slides, 3)

    print(f"\n📐 Building carousel manuscript: {title}")
    print(f"   Framework: {framework} | Content slides: {num_content_slides}")

    print("  ✍  Writing hook slide (chunk 1/4)")
    hook = generate_hook_slide(title, pitch, vertical, framework)
    hook_slide = {"slide_number": 1, "headline": hook["headline"], "subheadline": hook["subheadline"]}

    print(f"  ✍  Writing {num_content_slides} content slides (chunk 2/4)")
    content_slides = generate_content_slides(title, pitch, framework, num_content_slides)

    print("  ✍  Writing CTA slide (chunk 3/4)")
    cta_slide = generate_cta_slide(title, vertical, last_slide_number=num_content_slides + 2)

    print("  ✍  Writing caption + hashtags (chunk 4/4)")
    caption_data = generate_caption_and_hashtags(title, pitch, vertical)

    all_slides = [hook_slide] + content_slides + [cta_slide]

    if refine:
        print("  🔍 Quality pass: critiquing and tightening every slide...")
        all_slides = [refine_slide(s) for s in all_slides]

    for s in all_slides:
        s["alt_text"] = generate_alt_text(s)

    manuscript = {
        "title": title,
        "pitch": pitch,
        "vertical": vertical,
        "framework": framework,
        "slide_count": len(all_slides),
        "slides": all_slides,
        "caption": caption_data["caption"],
        "hashtags": caption_data["hashtags"],
        # Real market-search result titles (from carousel_niche_agent.py's
        # market_signal_check) — carried through so carousel_design_agent.py
        # can use them as extra image-content hints, not just the title.
        "market_keywords": market_keywords or [],
        "generated_at": now_iso(),
    }
    print(f"  ✓ Manuscript complete: {len(all_slides)} slides")
    return manuscript
