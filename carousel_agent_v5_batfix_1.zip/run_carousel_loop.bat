@echo off
title Carousel Agent - Loop Runner
cd /d "%~dp0"

REM ============================================================
REM  CAROUSEL AGENT - one-click "keep this running" launcher.
REM  Put this .bat in the SAME folder as carousel_loop_agent.py.
REM  Works whether that folder is ai\ directly or a subfolder like
REM  ai\carousel_agent\ - the Python side auto-detects the layout.
REM
REM  Edit the two SET lines below once for your machine, then just
REM  double-click this file whenever you want the pipeline running.
REM ============================================================

set "PYTHON_EXE=python"
set "COMFYUI_LAUNCHER="
set "COMFY_URL=http://127.0.0.1:8188"

echo ============================================================
echo  CAROUSEL AGENT
echo ============================================================
echo Working folder : %cd%
echo Python         : %PYTHON_EXE%
echo ComfyUI URL    : %COMFY_URL%
echo ============================================================
echo.

REM ---- 0. sanity-check Python is reachable ----
%PYTHON_EXE% --version >nul 2>&1
if errorlevel 1 goto no_python
goto check_pillow

:no_python
echo [ERROR] "%PYTHON_EXE%" was not found on PATH.
echo Edit PYTHON_EXE at the top of this .bat to your full python.exe
echo path, for example:
echo   set "PYTHON_EXE=C:\Python311\python.exe"
pause
exit /b 1

:check_pillow
REM ---- 1. make sure the one real dependency (Pillow) is installed ----
%PYTHON_EXE% -c "import PIL" >nul 2>&1
if errorlevel 1 echo Installing Pillow, first run only...
if errorlevel 1 %PYTHON_EXE% -m pip install --quiet --disable-pip-version-check pillow

REM ---- 2. is ComfyUI already up? ----
%PYTHON_EXE% -c "import urllib.request,os;urllib.request.urlopen(os.environ.get('COMFY_URL','http://127.0.0.1:8188')+'/system_stats',timeout=2)" >nul 2>&1
if errorlevel 1 goto comfy_down
echo ComfyUI already running at %COMFY_URL% - good.
goto run_loop

:comfy_down
if "%COMFYUI_LAUNCHER%"=="" goto comfy_none
echo ComfyUI not reachable at %COMFY_URL% - starting it now...
start "ComfyUI" cmd /c "%COMFYUI_LAUNCHER%"
echo Waiting about 20 seconds for ComfyUI to come online...
timeout /t 20 /nobreak >nul
goto run_loop

:comfy_none
echo [NOTE] ComfyUI is not reachable at %COMFY_URL% and no
echo COMFYUI_LAUNCHER is set near the top of this .bat, so carousels
echo will use the built-in Pillow fallback art instead of ComfyUI this
echo run. That fallback is real, colorful, on-brand template art, not
echo a placeholder - but if you want actual ComfyUI-generated
echo illustrations, either start ComfyUI yourself first, or set
echo COMFYUI_LAUNCHER above to your ComfyUI launcher's file path.
goto run_loop

:run_loop
echo.
echo Loop controls, from another window in this same folder:
echo   carousel_status.bat   - show progress
echo   carousel_pause.bat    - pause after the current carousel
echo   carousel_resume.bat   - resume
echo   carousel_stop.bat     - stop cleanly
echo Or just close this window, or press Ctrl+C, to stop immediately.
echo.

REM ---- 3. run forever, auto-restart this window if the python
REM         process itself ever dies outright. The loop's own
REM         per-job crash handling already lives inside
REM         carousel_loop_agent.py and does not need this - this is
REM         only a safety net for the whole interpreter going down. ----
:loop
echo [%date% %time%] Starting carousel_loop_agent.py ...
%PYTHON_EXE% carousel_loop_agent.py run
echo.
echo [%date% %time%] carousel_loop_agent.py exited.
echo Restarting in 10 seconds - close this window or press Ctrl+C to stop for good.
timeout /t 10 /nobreak >nul
goto loop
