"""
CAROUSEL NICHE INTELLIGENCE AGENT
====================================

Same role ebook_topic_agent.py plays for ebooks: brainstorm specific,
sellable carousel product ideas across the premium-client verticals in
carousel_design_brief.py, check a real market signal for each, score on
design-appeal + sellability, and pick the best one not made recently.

Reuses seo_agent.py's ask_ollama/web_search utilities exactly like
ebook_topic_agent.py does — no shared file is modified, this is a pure
additive sibling.

Pipeline:
    PREMIUM CLIENT VERTICALS
        |
        v
    OLLAMA: generate narrow candidate carousel ideas per vertical
        |
        v
    LIGHT MARKET SIGNAL CHECK (real web search — does anyone pay for a
    template like this?)
        |
        v
    OLLAMA: score each candidate on design_appeal + sellability
        |
        v
    SELECT BEST (skip anything made in the last 30 days)
        |
        v
    data/carousel/selected_niche.json
"""

from __future__ import annotations

import json
import logging
import random
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _carousel_bootstrap import PROJECT_ROOT  # noqa: E402 — resolves ai/ + project root regardless of subfolder placement

from seo_agent import (  # noqa: E402
    ask_ollama,
    extract_json,
    clean_text,
    unique_strings,
    now_iso,
    web_search,
)
from carousel_design_brief import PREMIUM_CLIENT_VERTICALS, CONTENT_FRAMEWORKS  # noqa: E402

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("carousel_niche_agent")

BASE_DIR = PROJECT_ROOT
DATA_DIR = BASE_DIR / "data" / "carousel"
DATA_DIR.mkdir(parents=True, exist_ok=True)

HISTORY_FILE = DATA_DIR / "niche_history.json"
CANDIDATES_FILE = DATA_DIR / "niche_candidates.json"
SELECTED_FILE = DATA_DIR / "selected_niche.json"

CANDIDATES_PER_VERTICAL = 4
MIN_HISTORY_GAP_DAYS = 30

_FALLBACK_NICHES = [
    {
        "title": "5 Signs You've Outgrown Your Current Business Model",
        "vertical": "business_coaches_consultants",
        "framework": "utility_checklist",
    },
    {
        "title": "The 3-Step Listing Prep Checklist Sellers Actually Follow",
        "vertical": "real_estate_agents",
        "framework": "step_by_step",
    },
]


def generate_candidates(vertical_key: str, vertical_brief: str) -> List[Dict[str, Any]]:
    frameworks_list = ", ".join(CONTENT_FRAMEWORKS.keys())
    prompt = f"""
You are a strategist for a solo creator who designs and sells premium,
on-brand Instagram carousel templates to real businesses for $49-$249 per
template pack (not $2-3 Etsy impulse buys).

Brainstorm {CANDIDATES_PER_VERTICAL} SPECIFIC, NARROW carousel post ideas
for this client vertical: {vertical_brief}

Hard requirements for every idea:
- Specific enough to become one real carousel (not "tips for coaches" —
  something like "The 3 pricing mistakes killing your discovery calls")
- A real business in this vertical would want to post this AND would pay
  for it to be professionally designed
- Pick ONE content framework per idea from: {frameworks_list}
- Not medical, legal, or financial advice that could cause real harm if
  wrong — practical, tactical content only

Return ONLY this JSON object:
{{
  "candidates": [
    {{
      "title": "specific working title for the carousel",
      "one_line_pitch": "the exact outcome/problem this carousel addresses",
      "framework": "one of: {frameworks_list}"
    }}
  ]
}}
"""
    raw = ask_ollama(prompt)
    if not raw:
        return []
    try:
        data = extract_json(raw)
        candidates = data.get("candidates", [])
    except Exception as e:
        logger.warning(f"Could not parse candidates for {vertical_key}: {e}")
        return []

    out = []
    for c in candidates:
        title = clean_text(c.get("title", ""))
        if not title:
            continue
        framework = clean_text(c.get("framework", "")) or "step_by_step"
        if framework not in CONTENT_FRAMEWORKS:
            framework = "step_by_step"
        out.append({
            "title": title,
            "one_line_pitch": clean_text(c.get("one_line_pitch", "")),
            "vertical": vertical_key,
            "framework": framework,
        })
    return out


def market_signal_check(title: str, vertical_key: str) -> Dict[str, Any]:
    """
    Real-world check: does the template marketplace already show demand
    for content like this? A few hits is a good sign (proven willingness
    to pay for this kind of template), zero is a warning sign.
    """
    vertical_label = vertical_key.replace("_", " ")
    queries = [
        f"{title} instagram carousel template",
        f"{vertical_label} instagram carousel template etsy",
    ]
    hits = 0
    sample_titles: List[str] = []
    for q in queries:
        results = web_search(q, limit=5)
        hits += len(results)
        sample_titles.extend(r.get("title", "") for r in results[:3])
        time.sleep(0.3)
    return {
        "query_hit_count": hits,
        "sample_results": unique_strings(sample_titles, limit=6),
    }


def score_candidate(candidate: Dict[str, Any], signal: Dict[str, Any]) -> Dict[str, Any]:
    prompt = f"""
Score this Instagram carousel template idea for a solo creator selling
premium, on-brand template packs for $49-$249.

Idea: {candidate['title']}
Pitch: {candidate['one_line_pitch']}
Framework: {candidate['framework']}

Real market signal (from live web search — {signal['query_hit_count']}
relevant results found; examples: {signal['sample_results']}):

Score honestly on:
- design_appeal_score (1-10): how visually compelling/scroll-stopping
  could this be as a carousel, independent of the copy?
- sellability_score (1-10): based on the market signal above, how likely
  is a real business in this vertical to pay $49-$249 for this?
- competition_level: "low", "medium", or "high"
- reasoning: one or two honest sentences

Return ONLY this JSON:
{{
  "design_appeal_score": 0,
  "sellability_score": 0,
  "competition_level": "low",
  "reasoning": ""
}}
"""
    raw = ask_ollama(prompt)
    if not raw:
        return {
            "design_appeal_score": 5,
            "sellability_score": 5,
            "competition_level": "unknown",
            "reasoning": "Ollama unavailable — neutral default score.",
        }
    try:
        data = extract_json(raw)
        return {
            "design_appeal_score": int(data.get("design_appeal_score", 5)),
            "sellability_score": int(data.get("sellability_score", 5)),
            "competition_level": clean_text(data.get("competition_level", "unknown")) or "unknown",
            "reasoning": clean_text(data.get("reasoning", "")),
        }
    except Exception as e:
        logger.warning(f"Scoring parse failed: {e}")
        return {
            "design_appeal_score": 5,
            "sellability_score": 5,
            "competition_level": "unknown",
            "reasoning": "Score parsing failed — neutral default.",
        }


def composite_score(candidate: Dict[str, Any]) -> float:
    design = candidate.get("design_appeal_score", 5)
    sell = candidate.get("sellability_score", 5)
    signal_hits = candidate.get("market_signal", {}).get("query_hit_count", 0)
    competition_penalty = {
        "low": 1.0, "medium": 0.85, "high": 0.65, "unknown": 0.9,
    }.get(candidate.get("competition_level", "unknown"), 0.9)
    base = (design * 0.4) + (sell * 0.6)
    signal_bonus = min(signal_hits, 10) * 0.15
    return round((base + signal_bonus) * competition_penalty, 2)


def load_history() -> List[Dict[str, Any]]:
    if not HISTORY_FILE.exists():
        return []
    try:
        return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_history(history: List[Dict[str, Any]]) -> None:
    HISTORY_FILE.write_text(json.dumps(history, indent=2, ensure_ascii=False), encoding="utf-8")


def add_to_history(title: str) -> None:
    history = load_history()
    history.append({"title": title, "chosen_at": now_iso()})
    save_history(history)


def recently_used(title: str, history: List[Dict[str, Any]]) -> bool:
    title_l = title.lower().strip()
    now = datetime.now(timezone.utc)
    for entry in history:
        if entry.get("title", "").lower().strip() != title_l:
            continue
        try:
            chosen_at = datetime.fromisoformat(entry["chosen_at"])
        except Exception:
            return True
        if (now - chosen_at).days < MIN_HISTORY_GAP_DAYS:
            return True
    return False


def run_carousel_niche_agent() -> Dict[str, Any]:
    print("\n" + "=" * 70)
    print("CAROUSEL NICHE INTELLIGENCE AGENT")
    print("=" * 70)

    history = load_history()
    all_candidates: List[Dict[str, Any]] = []

    for vertical_key, vertical_brief in PREMIUM_CLIENT_VERTICALS.items():
        print(f"\n[Vertical: {vertical_key}] Generating candidates...")
        candidates = generate_candidates(vertical_key, vertical_brief)
        print(f"  → {len(candidates)} candidates generated")

        for c in candidates:
            if recently_used(c["title"], history):
                print(f"  ⏭  Skipping (used recently): {c['title']}")
                continue
            print(f"  🔎 Checking market signal: {c['title']}")
            signal = market_signal_check(c["title"], vertical_key)
            c["market_signal"] = signal
            c.update(score_candidate(c, signal))
            c["composite_score"] = composite_score(c)
            print(
                f"     design={c['design_appeal_score']} sell={c['sellability_score']} "
                f"competition={c['competition_level']} → score={c['composite_score']}"
            )
            all_candidates.append(c)

    if not all_candidates:
        logger.warning(
            "No viable candidates found (Ollama may be unreachable, or "
            "everything was filtered as recently used) — using a fallback "
            "niche so this run still produces a carousel."
        )
        fb = random.choice(_FALLBACK_NICHES)
        selected = {
            "title": fb["title"],
            "one_line_pitch": f"A practical carousel on {fb['title'].lower()}.",
            "vertical": fb["vertical"],
            "framework": fb["framework"],
            "composite_score": 0.0,
            "reasoning": "Fallback niche — niche intelligence was unavailable this run.",
            "market_sample_titles": [],
            "selected_at": now_iso(),
        }
        SELECTED_FILE.write_text(json.dumps(selected, indent=2, ensure_ascii=False), encoding="utf-8")
        add_to_history(fb["title"])
        return selected

    all_candidates.sort(key=lambda c: c["composite_score"], reverse=True)
    CANDIDATES_FILE.write_text(json.dumps(all_candidates, indent=2, ensure_ascii=False), encoding="utf-8")

    best = all_candidates[0]
    selected = {
        "title": best["title"],
        "one_line_pitch": best["one_line_pitch"],
        "vertical": best["vertical"],
        "framework": best["framework"],
        "composite_score": best["composite_score"],
        "reasoning": best.get("reasoning", ""),
        # Real market-search result titles from market_signal_check() above —
        # threaded through to carousel_design_agent.py as image-content hints,
        # per "make SEO engine search best topics from market and generate
        # images for them."
        "market_sample_titles": best.get("market_signal", {}).get("sample_results", []),
        "selected_at": now_iso(),
    }
    SELECTED_FILE.write_text(json.dumps(selected, indent=2, ensure_ascii=False), encoding="utf-8")
    add_to_history(best["title"])

    print("\n" + "=" * 70)
    print("SELECTED CAROUSEL NICHE")
    print("=" * 70)
    print(f"Title     : {selected['title']}")
    print(f"Vertical  : {selected['vertical']}")
    print(f"Framework : {selected['framework']}")
    print(f"Score     : {selected['composite_score']}")
    print("=" * 70)
    return selected


if __name__ == "__main__":
    run_carousel_niche_agent()
