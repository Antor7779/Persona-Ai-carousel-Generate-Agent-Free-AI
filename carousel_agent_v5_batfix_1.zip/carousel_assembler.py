"""
CAROUSEL ASSEMBLER
=====================

Takes one manuscript (from carousel_content_agent.py) and turns it into
one complete, numbered, self-contained product folder — mirrors
ebook_pdf_agent.py's "one numbered folder per book" pattern.

    data/carousel/output/<NNN>_<slug>/
        slides_content.json      <- the editable source of truth
        editable.html            <- browser-editable version (real text)
        slide_01_hook.png ... slide_0N_cta.png   <- IG-ready renders, in
                                                     upload order
        backgrounds/              <- raw background art, pre-text, in
                                      case you want to redesign
        thumbnail.jpg             <- slide 1, for quick preview
        caption_and_hashtags.txt  <- ready to paste into IG
        metadata.txt              <- title/vertical/framework/pricing/
                                      how it was generated

Every content field the folder contains comes straight from the
manuscript JSON — nothing here invents new copy, this module is purely
"lay it out on disk."
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _carousel_bootstrap import PROJECT_ROOT  # noqa: E402 — resolves ai/ + project root regardless of subfolder placement

from carousel_design_agent import (  # noqa: E402
    generate_background,
    composite_slide,
    render_carousel_html,
    get_palette,
    pick_icon_names,
)
from carousel_svg_export import render_slide_svg, export_icon_library  # noqa: E402

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("carousel_assembler")

BASE_DIR = PROJECT_ROOT
OUTPUT_DIR = BASE_DIR / "data" / "carousel" / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

COUNTER_FILE = OUTPUT_DIR.parent / "carousel_counter.json"


def _next_number() -> int:
    if COUNTER_FILE.exists():
        try:
            n = json.loads(COUNTER_FILE.read_text(encoding="utf-8")).get("last", 0) + 1
        except Exception:
            n = 1
    else:
        n = 1
    COUNTER_FILE.write_text(json.dumps({"last": n}), encoding="utf-8")
    return n


def _slugify(title: str, max_len: int = 50) -> str:
    slug = "".join(c if c.isalnum() else "_" for c in title.lower())
    while "__" in slug:
        slug = slug.replace("__", "_")
    return slug.strip("_")[:max_len]


def _role_for_index(i: int, total: int) -> str:
    if i == 0:
        return "hook"
    if i == total - 1:
        return "cta"
    return "content"


def assemble_carousel(manuscript: Dict[str, Any], suggested_price_usd: str = "$79-$149") -> Dict[str, Any]:
    title = manuscript["title"]
    vertical = manuscript.get("vertical", "general")
    framework = manuscript.get("framework", "step_by_step")
    slides = manuscript["slides"]
    palette = get_palette(vertical)

    number = _next_number()
    slug = _slugify(title)
    folder = OUTPUT_DIR / f"{number:03d}_{slug}"
    bg_dir = folder / "backgrounds"
    folder.mkdir(parents=True, exist_ok=True)
    bg_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n🖼  Rendering {len(slides)} slides into {folder.name}/")

    market_keywords = manuscript.get("market_keywords", [])
    all_icon_names: List[str] = []

    slide_paths = []
    svg_paths = []
    for i, slide in enumerate(slides):
        role = _role_for_index(i, len(slides))
        bg_path = bg_dir / f"bg_{i + 1:02d}_{role}.png"
        generate_background(vertical, role, palette, bg_path, topic=title, slide=slide, market_keywords=market_keywords)

        slide_filename = f"slide_{i + 1:02d}_{role}.png"
        slide_out = folder / slide_filename
        composite_slide(bg_path, slide, role, palette, slide_out)
        slide_paths.append(slide_out)

        # Illustrator-editable version: same background, real vector text
        # on top — open in Illustrator and every line is a live text object.
        svg_out = folder / f"slide_{i + 1:02d}_{role}.svg"
        render_slide_svg(slide_out, slide, role, palette, svg_out)
        svg_paths.append(svg_out)

        all_icon_names.extend(pick_icon_names(vertical, topic=title, slide=slide, market_keywords=market_keywords, max_icons=5))
        print(f"  ✓ {slide_filename}  (+ .svg)")

    # reusable icon components actually used in THIS carousel — real
    # vector .svg, one per icon, in this carousel's own brand colors
    icons_dir = folder / "icons"
    icon_files = export_icon_library(all_icon_names, palette, icons_dir)
    print(f"  ✓ {len(icon_files)} reusable icon component(s) in icons/")

    # thumbnail = a smaller copy of slide 1 for quick preview
    from PIL import Image
    thumb = Image.open(slide_paths[0]).convert("RGB")
    thumb.thumbnail((400, 500))
    thumb.save(folder / "thumbnail.jpg", quality=90)

    # editable JSON source of truth
    (folder / "slides_content.json").write_text(
        json.dumps(manuscript, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # editable HTML version
    render_carousel_html(manuscript, palette, folder / "editable.html")

    # caption + hashtags, ready to paste
    hashtag_line = " ".join(f"#{h}" for h in manuscript.get("hashtags", []))
    (folder / "caption_and_hashtags.txt").write_text(
        f"{manuscript.get('caption', '')}\n\n{hashtag_line}\n", encoding="utf-8"
    )

    # metadata
    metadata = (
        f"Title: {title}\n"
        f"Vertical: {vertical}\n"
        f"Framework: {framework}\n"
        f"Slide count: {len(slides)}\n"
        f"Dimensions: 1080x1350 (4:5 portrait — current IG carousel best practice)\n"
        f"Suggested price range: {suggested_price_usd}\n"
        f"Generated at: {manuscript.get('generated_at', '')}\n"
        f"\n"
        f"Posting order: upload slide_01 through slide_{len(slides):02d} in filename order.\n"
        f"Alt text for each slide is included in slides_content.json (per-slide \"alt_text\" field) —\n"
        f"add it via Instagram's \"Advanced settings > Accessibility > Write alt text\" per slide.\n"
        f"\n"
        f"Design note: backgrounds/ holds the raw pre-text art for each slide if you want to\n"
        f"redesign without touching the copy. editable.html holds the same copy as real,\n"
        f"directly-editable HTML text (open in any browser). slides_content.json is the single\n"
        f"source of truth all of these were generated from.\n"
        f"\n"
        f"Illustrator: slide_NN_role.svg opens directly in Adobe Illustrator (File > Open) —\n"
        f"the background art is a placed image and the headline/body/CTA copy sits on top as\n"
        f"real, separate, live text objects you can click and retype. There's no public writer\n"
        f"for Illustrator's proprietary binary .ai format, so this is the honest equivalent —\n"
        f"Illustrator opens/edits/saves SVG natively, nothing is lost.\n"
        f"icons/ holds this carousel's actual icon objects as their own small, fully vector,\n"
        f"reusable .svg files in this carousel's brand colors — drag any of them into another\n"
        f"design, recolor or rescale freely.\n"
    )
    (folder / "metadata.txt").write_text(metadata, encoding="utf-8")

    print(f"✅  Carousel folder complete: {folder}")
    return {
        "folder": str(folder),
        "number": number,
        "slide_count": len(slides),
        "slides": [str(p) for p in slide_paths],
        "editable_svgs": [str(p) for p in svg_paths],
        "icons": [str(p) for p in icon_files],
        "editable_html": str(folder / "editable.html"),
        "editable_json": str(folder / "slides_content.json"),
        "thumbnail": str(folder / "thumbnail.jpg"),
    }
