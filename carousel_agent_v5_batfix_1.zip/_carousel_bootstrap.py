"""
CAROUSEL BOOTSTRAP — path resolution only. No other imports, so every
other carousel_*.py can import this FIRST, before it needs seo_agent.py /
image_agent.py / character_profile.py, without any chicken-and-egg problem.

Why this exists: the carousel files were originally written assuming they
sit directly in ai/, right next to seo_agent.py and image_agent.py
(`sys.path.insert(0, str(Path(__file__).resolve().parent))` was enough).
In practice they often end up organized into a subfolder instead — e.g.
E:\AI_Script_writer\ai\carousel_agent\ — and from there that same line
only adds carousel_agent\ to sys.path, NOT ai\, so `from seo_agent import
...` / `import image_agent` fail (loudly for seo_agent — a hard
ImportError — and silently for image_agent, since carousel_design_agent.py
wraps that one in try/except and just disables ComfyUI generation without
any error, which is a confusing way to lose the feature).

This module searches upward from its own folder for the real ai\
directory (identified by seo_agent.py living in it) and adds BOTH that
directory and its own folder to sys.path, then exposes AI_DIR and
PROJECT_ROOT so every carousel_*.py can compute its data folder
(data/carousel/...) relative to the actual project root
(E:\AI_Script_writer\, i.e. AI_DIR's parent) instead of guessing a fixed
number of ".parent" hops that breaks depending on where these files live.

Works unchanged whether the carousel_*.py files sit directly in ai/ (the
original layout) or in a subfolder like ai/carousel_agent/ (today's
layout) — nothing else in this project needs to be moved or renamed.
"""

from __future__ import annotations

import sys
from pathlib import Path

_THIS_DIR = Path(__file__).resolve().parent


def _find_ai_dir(start: Path, max_up: int = 6) -> Path:
    d = start
    for _ in range(max_up):
        if (d / "seo_agent.py").exists():
            return d
        if d.parent == d:  # reached filesystem root
            break
        d = d.parent
    # Not found within max_up levels — assume the original "files live
    # directly in ai/" layout so behavior is unchanged for that case.
    return start


AI_DIR: Path = _find_ai_dir(_THIS_DIR)
PROJECT_ROOT: Path = AI_DIR.parent

for _p in (str(_THIS_DIR), str(AI_DIR)):
    if _p not in sys.path:
        sys.path.insert(0, _p)
