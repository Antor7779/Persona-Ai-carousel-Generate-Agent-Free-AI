"""
CAROUSEL MASTER AGENT
========================

Orchestrates ONE complete run of the carousel pipeline, same shape as
ebook_master_agent.py:

    1. Pick a niche   (carousel_niche_agent.py — or a title you pass in)
    2. Write manuscript (carousel_content_agent.py — chunked: hook,
       content slides, CTA, caption+hashtags — then a quality pass that
       critiques and tightens every slide)
    3. Render + assemble (carousel_design_agent.py + carousel_assembler.py)
       — one numbered, fully editable folder per carousel

For the infinite "keep making carousels forever" behavior, see
carousel_loop_agent.py, which calls run_carousel_pipeline() in a loop.

Does not import, modify, or depend on anything from the ebook or video
pipelines beyond the shared, read-only utilities (seo_agent.py,
image_agent.py) — running this alongside ebook_loop_agent.py or
video_loop_agent.py is safe; they share no mutable state (separate
data/carousel/ directory, separate history/counter files).
"""

from __future__ import annotations

import argparse
import logging
from typing import Any, Dict, Optional

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _carousel_bootstrap import PROJECT_ROOT  # noqa: E402,F401 — resolves ai/ + project root regardless of subfolder placement

from carousel_niche_agent import run_carousel_niche_agent
from carousel_content_agent import write_carousel_manuscript
from carousel_assembler import assemble_carousel
from carousel_design_brief import CONTENT_FRAMEWORKS, PREMIUM_CLIENT_VERTICALS

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("carousel_master_agent")


def run_carousel_pipeline(
    title: Optional[str] = None,
    pitch: str = "",
    vertical: Optional[str] = None,
    framework: Optional[str] = None,
    refine: bool = True,
    suggested_price_usd: str = "$79-$149",
) -> Dict[str, Any]:

    print("\n" + "=" * 70)
    print("🎠  CAROUSEL AGENT — Niche → Content (chunked+refined) → Design → Folder")
    print("=" * 70)

    # ---- 1. Niche ----
    market_keywords: list = []
    if not title:
        print("\n[1/3] Niche Discovery")
        selected = run_carousel_niche_agent()
        title = selected["title"]
        pitch = selected.get("one_line_pitch", "")
        vertical = selected.get("vertical", vertical or "business_coaches_consultants")
        framework = selected.get("framework", framework or "step_by_step")
        market_keywords = selected.get("market_sample_titles", [])
    else:
        print(f"\n[1/3] Using provided title: {title}")
        vertical = vertical or "business_coaches_consultants"
        framework = framework or "step_by_step"

    if vertical not in PREMIUM_CLIENT_VERTICALS:
        logger.warning(f"Unknown vertical {vertical!r} — defaulting to business_coaches_consultants")
        vertical = "business_coaches_consultants"
    if framework not in CONTENT_FRAMEWORKS:
        logger.warning(f"Unknown framework {framework!r} — defaulting to step_by_step")
        framework = "step_by_step"

    # ---- 2. Manuscript (chunked content + quality refine pass) ----
    print(f"\n[2/3] Writing Manuscript (vertical={vertical}, framework={framework}, refine={refine})")
    manuscript = write_carousel_manuscript(title, pitch, vertical, framework, refine=refine, market_keywords=market_keywords)

    # ---- 3. Design + assemble into one numbered, editable folder ----
    print("\n[3/3] Rendering + Assembling")
    result = assemble_carousel(manuscript, suggested_price_usd=suggested_price_usd)

    print("\n" + "=" * 70)
    print("✅  Carousel pipeline complete")
    print("=" * 70)
    print(f"📁  Folder       : {result['folder']}")
    print(f"🖼   Slides       : {result['slide_count']}")
    print(f"✏️   Editable JSON: {result['editable_json']}")
    print(f"🌐  Editable HTML: {result['editable_html']}")
    print("=" * 70)

    return {
        "status": "success",
        "title": title,
        "vertical": vertical,
        "framework": framework,
        **result,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--title", default=None, help="Skip niche discovery, use this title")
    ap.add_argument("--pitch", default="")
    ap.add_argument("--vertical", choices=list(PREMIUM_CLIENT_VERTICALS.keys()), default=None)
    ap.add_argument("--framework", choices=list(CONTENT_FRAMEWORKS.keys()), default=None)
    ap.add_argument("--no-refine", action="store_true", help="Skip the second quality/critique pass")
    ap.add_argument("--price", default="$79-$149")
    args = ap.parse_args()

    run_carousel_pipeline(
        title=args.title,
        pitch=args.pitch,
        vertical=args.vertical,
        framework=args.framework,
        refine=not args.no_refine,
        suggested_price_usd=args.price,
    )


if __name__ == "__main__":
    main()
